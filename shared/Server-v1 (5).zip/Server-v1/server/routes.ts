import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import * as schema from "@shared/schema";
import {
  insertUserSchema, insertAssetSchema, insertActivitySchema,
  insertLicenseSchema, insertLicenseAssignmentSchema, insertComponentSchema, insertAccessorySchema,
  insertSystemSettingsSchema, systemSettings, AssetStatus,
  LicenseStatus, AccessoryStatus, users
} from "@shared/schema";
import { eq, sql, desc } from "drizzle-orm";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import { db } from "./db";
import * as fs from 'fs';
import * as path from 'path';
import { WebSocketServer, WebSocket } from 'ws';
import { exec, spawn } from 'child_process';
import { promisify } from 'util';
import * as dns from 'dns';
import * as net from 'net';

import { setupAuth } from "./auth";
import { defaultRoles } from "./roles"; // Import defaultRoles
import { externalLogger } from "./logger"; // Assuming externalLogger is set up in logger.ts

// Import scheduled backup functions and types
import { scheduleBackupJob, cancelScheduledBackup } from './backup'; // Assuming these functions exist and are correctly implemented in './backup'

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up authentication
  setupAuth(app);

  // Import necessary schemas
  const { insertZabbixSettingsSchema, insertZabbixSubnetSchema, insertDiscoveredHostSchema, insertVMMonitoringSchema, insertBitlockerKeySchema, insertVmInventorySchema } = schema;

  // Error handling middleware
  const handleError = (err: any, res: Response) => {
    console.error(err);
    if (err instanceof ZodError) {
      const validationError = fromZodError(err);
      return res.status(400).json({ message: validationError.message });
    }
    return res.status(500).json({ message: err.message || "Internal Server Error" });
  };

  // Authentication middleware
  const requireAuth = (req: Request, res: Response, next: NextFunction) => {
    if (!req.isAuthenticated()) {
      console.log(`Permission check failed: User not authenticated`);
      return res.status(401).json({ message: "Authentication required" });
    }
    next();
  };

  // Permission validation middleware
  const checkPermission = (resource: string, action: 'view' | 'edit' | 'add' | 'delete') => {
    return async (req: Request, res: Response, next: NextFunction) => {
      if (!req.isAuthenticated()) {
        console.log(`Permission check failed: User not authenticated`);
        return res.status(401).json({ message: "Not authenticated" });
      }

      console.log(`Checking permission for user ${req.user.username}: ${resource}.${action}`);
      console.log(`User isAdmin: ${req.user.isAdmin}, roleId: ${req.user.roleId}`);

      try {
        // Reload user data to ensure we have current permissions
        const currentUser = await storage.getUser(req.user.id);
        if (!currentUser) {
          console.log(`Permission denied: User not found in database`);
          return res.status(401).json({ message: "User not found" });
        }

        // Update session user data with current database state
        req.user.isAdmin = currentUser.isAdmin;
        req.user.roleId = currentUser.roleId;

        // Admin users always have full access
        if (currentUser.isAdmin === true || currentUser.isAdmin === 1) {
          console.log(`Permission granted: User is admin`);
          return next();
        }

        // Load permissions from role
        const { getPermissionsForRole } = await import("./roles");
        const userPermissions = getPermissionsForRole(currentUser.roleId);

        console.log(`Loaded permissions for roleId ${currentUser.roleId}:`, JSON.stringify(userPermissions, null, 2));

        if (!userPermissions) {
          console.log(`Permission denied: No permissions found for roleId ${currentUser.roleId}`);
          return res.status(403).json({
            message: `Access denied. No role permissions configured.`
          });
        }

        // Check if resource exists in permissions
        if (!userPermissions[resource]) {
          console.log(`Permission denied: No permissions for resource ${resource}`);
          return res.status(403).json({
            message: `Access denied. You don't have permission to access ${resource}.`
          });
        }

        // Check specific action permission
        const hasPermission = userPermissions[resource][action] === true;
        if (!hasPermission) {
          console.log(`Permission denied: No ${action} permission for resource ${resource}. Current permissions:`, userPermissions[resource]);
          return res.status(403).json({
            message: `Access denied. You don't have permission to ${action} ${resource}.`
          });
        }

        console.log(`Permission granted: User has ${action} permission for ${resource}`);

        // Update the request user object with current permissions for consistency
        req.user.permissions = userPermissions;
        req.user.isAdmin = currentUser.isAdmin;
        req.user.roleId = currentUser.roleId;

        next();
      } catch (error) {
        console.error(`Permission check error:`, error);
        return res.status(500).json({ message: "Permission check failed" });
      }
    };
  };

  // Helper function to make Zabbix API calls with proper error handling
  async function makeZabbixApiCall(url: string, username: string, password: string, method: string, params: any = {}, authToken?: string) {
    console.log(`Making Zabbix API call: ${method} to ${url}`);

    // Validate URL format
    if (!url || typeof url !== 'string') {
      throw new Error('Invalid Zabbix URL provided');
    }

    // Ensure URL ends with api_jsonrpc.php if it doesn't already
    let apiUrl = url.trim();
    if (!apiUrl.endsWith('api_jsonrpc.php')) {
      if (!apiUrl.endsWith('/')) {
        apiUrl += '/';
      }
      apiUrl += 'api_jsonrpc.php';
    }

    console.log(`Final API URL: ${apiUrl}`);

    const requestBody: any = {
      jsonrpc: '2.0',
      method: method,
      id: Date.now()
    };

    if (method === 'user.login') {
      // For login, params should contain username and password
      requestBody.params = {
        user: username,
        password: password
      };
    } else {
      // For other methods, include auth token and params
      if (authToken) {
        requestBody.auth = authToken;
      }
      requestBody.params = params || {};
    }

    console.log(`Request body:`, JSON.stringify(requestBody, null, 2));

    // Create abort controller for timeout
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30000); // 30 second timeout

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json-rpc',
          'Accept': 'application/json'
        },
        body: JSON.stringify(requestBody),
        signal: controller.signal
      });

      clearTimeout(timeoutId);
      console.log(`Response status: ${response.status}`);
      console.log(`Response headers:`, Object.fromEntries(response.headers.entries()));

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const contentType = response.headers.get('content-type');
      console.log(`Content-Type: ${contentType}`);

      if (!contentType || !contentType.includes('application/json')) {
        const textResponse = await response.text();
        console.log(`Non-JSON response received:`, textResponse.substring(0, 500));

        if (textResponse.includes('<!DOCTYPE') || textResponse.includes('<html')) {
          throw new Error('Received HTML instead of JSON. Check if the Zabbix URL is correct and points to the API endpoint (should end with /api_jsonrpc.php)');
        }

        throw new Error(`Expected JSON response but received: ${contentType}. Response: ${textResponse.substring(0, 200)}`);
      }

      const data = await response.json();
      console.log(`Response data:`, JSON.stringify(data, null, 2));

      if (data.error) {
        console.error(`Zabbix API error:`, data.error);
        throw new Error(`Zabbix API Error: ${data.error.message} (Code: ${data.error.code})`);
      }

      return data;
    } catch (error) {
      clearTimeout(timeoutId);
      console.error(`Zabbix API call failed:`, error);

      if (error.name === 'AbortError') {
        throw new Error(`Connection timeout: Zabbix server did not respond within 30 seconds. Check server status and network connectivity.`);
      }

      if (error.name === 'TypeError' && error.message.includes('fetch')) {
        throw new Error(`Network error: Unable to connect to Zabbix server at ${apiUrl}. Please check the URL and network connectivity.`);
      }

      throw error;
    }
  }

  // Zabbix Settings API
  app.get('/api/zabbix/settings', requireAuth, async (req: Request, res: Response) => {
    try {
      const settings = await storage.getZabbixSettings();

      // Don't return the password in the response for security
      if (settings && settings.password) {
        const { password, ...safeSettings } = settings;
        return res.json({
          ...safeSettings,
          configured: !!(settings.url && settings.username && settings.password)
        });
      }

      return res.json(settings || {
        url: '',
        username: '',
        password: '',
        autoSync: true,
        syncInterval: 60,
        configured: false
      });
    } catch (error) {
      console.error('Failed to get Zabbix settings:', error);
      return res.status(500).json({
        message: 'Failed to get Zabbix settings',
        error: error.message
      });
    }
  });

  app.post('/api/zabbix/settings', requireAuth, async (req: Request, res: Response) => {
    try {
      const settingsData = req.body;
      console.log('Saving Zabbix settings:', {
        url: settingsData.url,
        username: settingsData.username,
        hasPassword: !!settingsData.password,
        autoSync: settingsData.autoSync,
        syncInterval: settingsData.syncInterval
      });

      // Validate required fields
      if (!settingsData.url || !settingsData.username || !settingsData.password) {
        return res.status(400).json({
          message: 'URL, username, and password are required'
        });
      }

      const settings = await storage.saveZabbixSettings(settingsData);

      // Don't return the password in the response
      const { password, ...safeSettings } = settings;

      return res.json({
        ...safeSettings,
        configured: true,
        lastSync: new Date().toISOString()
      });
    } catch (error) {
      console.error('Failed to save Zabbix settings:', error);
      return res.status(500).json({
        message: 'Failed to save Zabbix settings',
        error: error.message
      });
    }
  });

  // Test Zabbix connection
  app.post('/api/zabbix/test-connection', requireAuth, async (req: Request, res: Response) => {
    try {
      const { url, username, password } = req.body;

      console.log('Testing Zabbix connection:', { url, username, hasPassword: !!password });

      if (!url || !username || !password) {
        return res.status(400).json({
          success: false,
          message: 'URL, username, and password are required for connection test',
          error: 'Missing required fields'
        });
      }

      // Validate URL format
      try {
        new URL(url);
      } catch (urlError) {
        return res.status(400).json({
          success: false,
          message: 'Invalid URL format. Please provide a valid HTTP/HTTPS URL.',
          error: 'Invalid URL format'
        });
      }

      // Test authentication
      const authResponse = await makeZabbixApiCall(url, username, password, 'user.login');

      if (!authResponse.result) {
        throw new Error('Authentication failed: Invalid username or password');
      }

      const authToken = authResponse.result;
      console.log('Authentication successful, token received');

      // Test getting hosts to verify API access
      const hostsResponse = await makeZabbixApiCall(url, username, password, 'host.get', {
        output: ['hostid', 'host', 'name', 'status'],
        limit: 10
      }, authToken);

      const hostCount = hostsResponse.result ? hostsResponse.result.length : 0;
      console.log(`Connection test successful, found ${hostCount} hosts`);

      return res.json({
        success: true,
        message: 'Connection successful',
        hostCount: hostCount,
        serverInfo: {
          url: url,
          apiVersion: '2.0'
        }
      });

    } catch (error) {
      console.error('Zabbix connection test failed:', error);

      let errorMessage = error.message || 'Connection test failed';
      let statusCode = 400;

      // Handle specific error types
      if (error.message.includes('Network error') || error.message.includes('fetch')) {
        errorMessage = 'Network error: Unable to connect to Zabbix server. Please check the URL and network connectivity.';
        statusCode = 503;
      } else if (error.message.includes('timeout')) {
        errorMessage = 'Connection timeout: Zabbix server did not respond within 30 seconds.';
        statusCode = 408;
      } else if (error.message.includes('HTML') || error.message.includes('<!DOCTYPE')) {
        errorMessage = 'Received HTML instead of JSON. Check if the URL points to the correct Zabbix API endpoint.';
        statusCode = 400;
      } else if (error.message.includes('authentication failed')) {
        errorMessage = 'Authentication failed: Invalid username or password.';
        statusCode = 401;
      }

      return res.status(statusCode).json({
        success: false,
        message: errorMessage,
        error: error.message
      });
    }
  });

  // Get Zabbix hosts
  app.get('/api/zabbix/hosts', requireAuth, async (req: Request, res: Response) => {
    try {
      const settings = await storage.getZabbixSettings();

      if (!settings || !settings.url || !settings.username || !settings.password) {
        return res.json({
          hosts: [],
          connected: false,
          count: 0,
          configured: false,
          error: 'Zabbix connection not configured. Please configure in Settings.'
        });
      }

      console.log('Fetching hosts from Zabbix:', { url: settings.url, username: settings.username });

      // Authenticate with Zabbix
      const authResponse = await makeZabbixApiCall(
        settings.url,
        settings.username,
        settings.password,
        'user.login'
      );

      if (!authResponse.result) {
        throw new Error('Zabbix authentication failed');
      }

      const authToken = authResponse.result;

      // Get hosts with detailed information
      const hostsResponse = await makeZabbixApiCall(
        settings.url,
        settings.username,
        settings.password,
        'host.get',
        {
          output: ['hostid', 'host', 'name', 'status', 'available', 'error', 'maintenance_status'],
          selectInterfaces: ['ip', 'dns', 'port'],
          selectItems: ['key_', 'lastvalue', 'units', 'name'],
          selectTriggers: ['triggerid', 'description', 'priority', 'status', 'value'],
          selectGroups: ['name'],
          selectParentTemplates: ['name'],
          filter: {
            status: 0 // Only enabled hosts
          }
        },
        authToken
      );

      if (!hostsResponse.result) {
        throw new Error('Failed to fetch hosts from Zabbix');
      }

      // Process hosts and extract performance metrics
      const processedHosts = hostsResponse.result.map((host: any) => {
        // Extract CPU usage
        const cpuItem = host.items?.find((item: any) =>
          item.key_.includes('system.cpu.util') ||
          item.key_.includes('cpu.usage') ||
          item.key_.includes('cpu.util')
        );

        // Extract memory usage
        const memoryItem = host.items?.find((item: any) =>
          item.key_.includes('vm.memory.util') ||
          item.key_.includes('memory.util') ||
          item.key_.includes('vm.memory.size[available]')
        );

        // Extract disk usage
        const diskItem = host.items?.find((item: any) =>
          item.key_.includes('vfs.fs.size') &&
          (item.key_.includes('pfree') || item.key_.includes('pused'))
        );

        // Extract uptime
        const uptimeItem = host.items?.find((item: any) =>
          item.key_.includes('system.uptime') ||
          item.key_.includes('net.if.in')
        );

        // Extract load average
        const loadItem = host.items?.find((item: any) =>
          item.key_.includes('system.cpu.load')
        );

        return {
          hostid: host.hostid,
          host: host.host,
          name: host.name || host.host,
          status: host.status === '0' ? 'enabled' : 'disabled',
          available: host.available === '1' ? 'available' :
                    host.available === '2' ? 'unavailable' : 'unknown',
          error: host.error || null,
          maintenance_status: host.maintenance_status === '1' ? 'maintenance' : 'normal',
          interfaces: host.interfaces || [],
          groups: host.groups?.map((g: any) => g.name) || [],
          templates: host.parentTemplates?.map((t: any) => t.name) || [],
          // Performance metrics
          cpu_usage: cpuItem ? parseFloat(cpuItem.lastvalue || '0') : undefined,
          memory_usage: memoryItem ? parseFloat(memoryItem.lastvalue || '0') : undefined,
          disk_usage: diskItem ? (diskItem.key_.includes('pfree') ?
            100 - parseFloat(diskItem.lastvalue || '0') :
            parseFloat(diskItem.lastvalue || '0')) : undefined,
          uptime: uptimeItem ? parseInt(uptimeItem.lastvalue || '0') : undefined,
          load_average: loadItem ? parseFloat(loadItem.lastvalue || '0') : undefined,
          // System information
          last_seen: new Date().toISOString(),
          // Active alerts from triggers
          active_alerts: host.triggers?.filter((trigger: any) =>
            trigger.value === '1' && trigger.status === '0'
          ).map((trigger: any) => ({
            triggerid: trigger.triggerid,
            description: trigger.description,
            priority: trigger.priority,
            severity: ['not_classified', 'information', 'warning', 'average', 'high', 'disaster'][trigger.priority] || 'unknown'
          })) || []
        };
      });

      console.log(`Successfully fetched ${processedHosts.length} hosts from Zabbix`);

      return res.json({
        hosts: processedHosts,
        connected: true,
        count: processedHosts.length,
        configured: true,
        server_url: settings.url,
        lastFetch: new Date().toISOString()
      });

    } catch (error) {
      console.error('Failed to fetch Zabbix hosts:', error);

      const settings = await storage.getZabbixSettings();
      const isConfigured = !!(settings?.url && settings?.username && settings?.password);

      return res.json({
        hosts: [],
        connected: false,
        count: 0,
        configured: isConfigured,
        server_url: settings?.url || null,
        error: error.message || 'Failed to connect to Zabbix server'
      });
    }
  });

  app.get('/api/zabbix/alerts', requireAuth, async (req: Request, res: Response) => {
    try {
      const settings = await storage.getZabbixSettings();

      if (!settings || !settings.url || !settings.username || !settings.password) {
        return res.json([]);
      }

      // Authenticate with Zabbix
      const authResponse = await makeZabbixApiCall(
        settings.url,
        settings.username,
        settings.password,
        'user.login'
      );

      if (!authResponse.result) {
        throw new Error('Zabbix authentication failed');
      }

      const authToken = authResponse.result;

      // Get active events (alerts)
      const eventsResponse = await makeZabbixApiCall(
        settings.url,
        settings.username,
        settings.password,
        'event.get',
        {
          output: ['eventid', 'objectid', 'name', 'severity', 'acknowledged', 'clock'],
          select_acknowledges: ['message', 'clock', 'userid'],
          selectHosts: ['name'],
          sortfield: 'clock',
          sortorder: 'DESC',
          time_from: Math.floor(Date.now() / 1000) - (7 * 24 * 60 * 60), // Last 7 days
          value: 1, // Only problem events
          limit: 100
        },
        authToken
      );

      if (!eventsResponse.result) {
        return res.json([]);
      }

      // Process events into alerts
      const alerts = eventsResponse.result.map((event: any) => {
        const age = Math.floor((Date.now() / 1000) - event.clock);
        const ageText = age < 3600 ? `${Math.floor(age / 60)}m` :
                      age < 86400 ? `${Math.floor(age / 3600)}h` :
                      `${Math.floor(age / 86400)}d`;

        return {
          eventid: event.eventid,
          name: event.name,
          severity: ['not_classified', 'information', 'warning', 'average', 'high', 'disaster'][event.severity] || 'unknown',
          status: 'problem',
          acknowledged: event.acknowledged === '1',
          timestamp: new Date(event.clock * 1000).toISOString(),
          age: ageText,
          hosts: event.hosts?.map((h: any) => h.name) || [],
          comments: event.acknowledges?.map((ack: any) => ({
            message: ack.message,
            time: new Date(ack.clock * 1000).toISOString(),
            userid: ack.userid
          })) || []
        };
      });

      return res.json(alerts);

    } catch (error) {
      console.error('Failed to fetch Zabbix alerts:', error);
      return res.json([]);
    }
  });

  // Acknowledge alert
  app.post('/api/zabbix/alerts/:eventId/acknowledge', requireAuth, async (req: Request, res: Response) => {
    try {
      const { eventId } = req.params;
      const { message } = req.body;

      const settings = await storage.getZabbixSettings();

      if (!settings || !settings.url || !settings.username || !settings.password) {
        return res.status(400).json({ message: 'Zabbix not configured' });
      }

      // Authenticate with Zabbix
      const authResponse = await makeZabbixApiCall(
        settings.url,
        settings.username,
        settings.password,
        'user.login'
      );

      if (!authResponse.result) {
        throw new Error('Zabbix authentication failed');
      }

      const authToken = authResponse.result;

      // Acknowledge the event
      const ackResponse = await makeZabbixApiCall(
        settings.url,
        settings.username,
        settings.password,
        'event.acknowledge',
        {
          eventids: [eventId],
          action: 6, // Close problem and acknowledge
          message: message || 'Acknowledged via SRPH-MIS'
        },
        authToken
      );

      if (!ackResponse.result) {
        throw new Error('Failed to acknowledge alert');
      }

      return res.json({
        success: true,
        eventId: eventId,
        message: 'Alert acknowledged successfully'
      });

    } catch (error) {
      console.error('Failed to acknowledge alert:', error);
      return res.status(500).json({
        message: 'Failed to acknowledge alert',
        error: error.message
      });
    }
  });

  // Sync hosts manually
  app.post('/api/zabbix/sync', requireAuth, async (req: Request, res: Response) => {
    try {
      const settings = await storage.getZabbixSettings();

      if (!settings || !settings.url || !settings.username || !settings.password) {
        return res.status(400).json({ message: 'Zabbix not configured' });
      }

      // This will trigger the same logic as GET /api/zabbix/hosts
      // but we'll also update the last sync time
      const hostsResponse = await fetch(`${req.protocol}://${req.get('host')}/api/zabbix/hosts`, {
        headers: {
          'Cookie': req.headers.cookie || ''
        }
      });

      const hostsData = await hostsResponse.json();

      if (hostsData.connected) {
        // Update settings with last sync time
        await storage.saveZabbixSettings({
          ...settings,
          lastSync: new Date().toISOString()
        });

        return res.json({
          success: true,
          hostCount: hostsData.count,
          lastSync: new Date().toISOString(),
          message: `Successfully synchronized ${hostsData.count} hosts`
        });
      } else {
        throw new Error(hostsData.error || 'Sync failed');
      }

    } catch (error) {
      console.error('Manual sync failed:', error);
      return res.status(500).json({
        message: 'Sync failed',
        error: error.message
      });
    }
  });

  // Get available templates
  app.get('/api/zabbix/templates', requireAuth, async (req: Request, res: Response) => {
    try {
      const settings = await storage.getZabbixSettings();

      if (!settings || !settings.url || !settings.username || !settings.password) {
        return res.json([]);
      }

      // Authenticate with Zabbix
      const authResponse = await makeZabbixApiCall(
        settings.url,
        settings.username,
        settings.password,
        'user.login'
      );

      if (!authResponse.result) {
        throw new Error('Zabbix authentication failed');
      }

      const authToken = authResponse.result;

      // Get templates
      const templatesResponse = await makeZabbixApiCall(
        settings.url,
        settings.username,
        settings.password,
        'template.get',
        {
          output: ['templateid', 'name', 'description'],
          sortfield: 'name'
        },
        authToken
      );

      return res.json(templatesResponse.result || []);

    } catch (error) {
      console.error('Failed to fetch templates:', error);
      return res.json([]);
    }
  });

  // Roles API
  app.get("/api/roles", requireAuth, async (req: Request, res: Response) => {
    try {
      const { getRolesWithUserCounts } = await import("./roles");
      const roles = await getRolesWithUserCounts();
      return res.json(roles);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.get("/api/roles/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      const { getRoleById } = await import("./roles");
      const roleId = parseInt(req.params.id);
      const role = getRoleById(roleId);

      if (!role) {
        return res.status(404).json({ message: "Role not found" });
      }

      return res.json(role);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.post("/api/roles", checkPermission('admin', 'add'), async (req: Request, res: Response) => {
    try {
      const { createRole } = await import("./roles");
      const roleData = req.body;

      const role = createRole(roleData);

      // Log activity
      await storage.createActivity({
        action: "create",
        itemType: "role",
        itemId: role.id,
        userId: req.user.id,
        timestamp: new Date().toISOString(),
        notes: `Role "${role.name}" created`,
      });

      return res.status(201).json(role);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Users API
  app.get("/api/users", checkPermission('users', 'view'), async (req: Request, res: Response) => {
    try {
      const users = await storage.getUsers();
      return res.json(users);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.get("/api/users/:id", checkPermission('users', 'view'), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const user = await storage.getUser(id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      return res.json(user);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.post("/api/users", checkPermission('users', 'add'), async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      const user = await storage.createUser(userData);

      // Log activity
      await storage.createActivity({
        action: "create",
        itemType: "user",
        itemId: user.id,
        userId: req.user.id,
        timestamp: new Date().toISOString(),
        notes: `User ${user.username} created`,
      });

      // Update role user counts after user creation
      const { updateRoleUserCounts } = await import("./roles");
      await updateRoleUserCounts();

      return res.status(201).json(user);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.patch("/api/users/:id", checkPermission('users', 'edit'), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }

      // Validate update data
      const updateData = insertUserSchema.partial().parse(req.body);

      // Check if username is being changed and if it's unique
      if (updateData.username && updateData.username !== existingUser.username) {
        const userWithSameUsername = await storage.getUserByUsername(updateData.username);
        if (userWithSameUsername) {
          return res.status(409).json({ message: "Username already exists" });
        }
      }

      console.log(`Updating user ${id} with data:`, updateData);

      // Handle password hashing if password is being updated
      let finalUpdateData = { ...updateData };
      if (updateData.password && updateData.password.trim() !== '') {
        const { scrypt, randomBytes } = await import('crypto');
        const { promisify } = await import('util');
        const scryptAsync = promisify(scrypt);

        console.log(`Hashing new password for user ${existingUser.username}`);
        const salt = randomBytes(16).toString("hex");
        const buf = (await scryptAsync(updateData.password, salt, 64)) as Buffer;
        finalUpdateData.password = `${buf.toString("hex")}.${salt}`;
        console.log(`Password hashed successfully for user ${existingUser.username}`);
      } else if (updateData.password === '') {
        // If empty string is provided, don't update password
        delete finalUpdateData.password;
      }

      // Handle role/admin status logic properly - avoid conflicts
      // Clear logic: Admin users should not have roleId, role users should not be admin
      if (updateData.isAdmin === true || updateData.isAdmin === "true") {
        finalUpdateData.roleId = null;
        finalUpdateData.isAdmin = true;
        console.log(`Setting user as admin, clearing roleId`);
      } else if (updateData.isAdmin === false || updateData.isAdmin === "false") {
        finalUpdateData.isAdmin = false;
        // Keep the roleId if it's being set, otherwise keep existing
        if (updateData.roleId !== undefined) {
          finalUpdateData.roleId = updateData.roleId;
        } else if (existingUser.roleId) {
          finalUpdateData.roleId = existingUser.roleId;
        }
        console.log(`Removing admin status, roleId: ${finalUpdateData.roleId}`);
      } else if (updateData.roleId !== undefined) {
        // Setting a role automatically removes admin status
        finalUpdateData.roleId = updateData.roleId;
        finalUpdateData.isAdmin = false;
        console.log(`Setting roleId ${updateData.roleId}, removing admin status`);
      }

      const updatedUser = await storage.updateUser(id, finalUpdateData);

      if (updatedUser) {
        const { getPermissionsForRole } = await import("./roles");

        // Load appropriate permissions based on final status
        if (updatedUser.isAdmin === true || updatedUser.isAdmin === 1) {
          updatedUser.permissions = {
            assets: { view: true, edit: true, add: true, delete: true },
            components: { view: true, edit: true, add: true, delete: true },
            accessories: { view: true, edit: true, add: true, delete: true },
            consumables: { view: true, edit: true, add: true, delete: true },
            licenses: { view: true, edit: true, add: true, delete: true },
            users: { view: true, edit: true, add: true, delete: true },
            reports: { view: true, edit: true, add: true, delete: true },
            admin: { view: true, edit: true, add: true, delete: true },
            vmMonitoring: { view: true, edit: true, add: true, delete: true },
            networkDiscovery: { view: true, edit: true, add: true, delete: true },
            bitlockerKeys: { view: true, edit: true, add: true, delete: true }
          };
          console.log(`Set admin permissions for user ${updatedUser.username}`);
        } else {
          updatedUser.permissions = getPermissionsForRole(updatedUser.roleId);
          console.log(`Set role-based permissions for user ${updatedUser.username} (roleId: ${updatedUser.roleId}):`, JSON.stringify(updatedUser.permissions, null, 2));
        }
      }

      // Log activity
      const activityNotes = updateData.password && updateData.password.trim() !== ''
        ? `User ${updatedUser?.username} updated (password changed, admin: ${updatedUser?.isAdmin}, roleId: ${updatedUser?.roleId})`
        : `User ${updatedUser?.username} updated (admin: ${updatedUser?.isAdmin}, roleId: ${updatedUser?.roleId})`;

      await storage.createActivity({
        action: "update",
        itemType: "user",
        itemId: id,
        userId: req.user.id,
        timestamp: new Date().toISOString(),
        notes: activityNotes,
      });

      // Update role user counts after user deletion
      const { updateRoleUserCounts } = await import("./roles");
      await updateRoleUserCounts();

      return res.json(updatedUser);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Update user permissions
  app.patch("/api/users/:id/permissions", checkPermission('users', 'edit'), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const { permissions } = req.body;
      if (!permissions) {
        return res.status(400).json({ message: "Permissions data required" });
      }

      const updatedUser = await storage.updateUser(id, { permissions });

      // Log activity
      await storage.createActivity({
        action: "update",
        itemType: "user",
        itemId: id,
        userId: req.user.id,
        timestamp: new Date().toISOString(),
        notes: `User ${updatedUser?.username} permissions updated`,
      });

      return res.json(updatedUser);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.put("/api/users/:id/permissions", checkPermission('users', 'edit'), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { permissions } = req.body;

      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        return res.status(404).json({ message: "User not found" });
      }

      const updatedUser = await storage.updateUser(id, { permissions });

      // Log activity
      await storage.createActivity({
        action: "update",
        itemType: "user",
        itemId: id,
        userId: req.user.id,
        timestamp: new Date().toISOString(),
        notes: `User ${existingUser.username} permissions updated`,
      });

      return res.json(updatedUser);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.delete("/api/users/:id", checkPermission('users', 'delete'), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      console.log(`Delete user endpoint called for ID: ${id}`);

      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }

      const existingUser = await storage.getUser(id);
      if (!existingUser) {
        console.log(`User with ID ${id} not found`);
        return res.status(404).json({ message: "User not found" });
      }

      // Prevent deleting the main admin user
      if (existingUser.isAdmin && existingUser.id === 1) {
        return res.status(403).json({ message: "Cannot delete the main administrator account" });
      }

      // Check if user has any assigned assets
      const assets = await storage.getAssets();
      const assignedAssets = assets.filter(asset => asset.assignedTo === id);

      if (assignedAssets.length > 0) {
        return res.status(400).json({
          message: `Cannot delete user. User has ${assignedAssets.length} asset(s) assigned. Please check in all assets first.`
        });
      }

      // Get user activities for logging purposes
      try {
        const userActivities = await storage.getActivitiesByUser(id);
        console.log(`User ${existingUser.username} has ${userActivities.length} activities associated - these will be preserved for audit`);
      } catch (activityError) {
        console.warn('Failed to get user activities for logging:', activityError);
      }

      console.log(`Deleting user: ${existingUser.username} (ID: ${id})`);
      const deleteResult = await storage.deleteUser(id);

      if (!deleteResult) {
        return res.status(500).json({ message: "Failed to delete user" });
      }

      // Log activity (after user deletion to avoid foreign key issues)
      try {
        await storage.createActivity({
          action: "delete",
          itemType: "user",
          itemId: id,
          userId: req.user?.id || null,
          timestamp: new Date().toISOString(),
          notes: `User ${existingUser.username} deleted by ${req.user?.username || 'system'}`,
        });
      } catch (activityError) {
        console.warn('Failed to log delete activity:', activityError);
      }

      console.log(`User ${existingUser.username} deleted successfully`);

      // Update role user counts after user deletion
      const { updateRoleUserCounts } = await import("./roles");
      await updateRoleUserCounts();

      return res.status(204).send();
    } catch (err) {
      console.error('Delete user error:', err);
      return handleError(err, res);
    }
  });

  // Assets API
  app.get("/api/assets", requireAuth, async (req: Request, res: Response) => {
    try {
      console.log('Assets API called by user:', req.user?.username);
      const assets = await storage.getAssets();
      console.log(`Found ${assets.length} assets`);

      if (!assets || !Array.isArray(assets)) {
        console.error('Invalid assets data returned from storage:', assets);
        return res.status(500).json({
          message: "Invalid assets data format",
          debug: { assetsType: typeof assets, isArray: Array.isArray(assets) }
        });
      }

      res.json(assets);
    } catch (error) {
      console.error("Error fetching assets:", error);
      res.status(500).json({
        message: "Failed to fetch assets",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/assets/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const asset = await storage.getAsset(id);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }
      return res.json(asset);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.post("/api/assets", requireAuth, async (req: Request, res: Response) => {
    try {
      const assetData = insertAssetSchema.parse(req.body);
      // Only check for duplicate asset tags, not Knox IDs
      if (assetData.assetTag) {
        const existingAsset = await storage.getAssetByTag(assetData.assetTag);
        if (existingAsset) {
          return res.status(409).json({ message: "Asset tag already exists" });
        }
      }

      // Create the asset
      const asset = await storage.createAsset(assetData);

      // Log activity
      await storage.createActivity({
        action: "create",
        itemType: "asset",
        itemId: asset.id,
        userId: req.user.id,
        timestamp: new Date().toISOString(),
        notes: `Asset ${asset.name} (${asset.assetTag}) created`,
      });

      // If Knox ID is provided, automatically checkout the asset to that Knox ID
      let updatedAsset = asset;
      if (assetData.knoxId && assetData.knoxId.trim() !== '') {
        // Find or create a user for this Knox ID
        // For now, we'll use admin user (id: 1) as the assignee
        const customNotes = `Asset automatically checked out to KnoxID: ${assetData.knoxId}`;
        updatedAsset = await storage.checkoutAsset(asset.id, 1, undefined, customNotes) || asset;

        // Log checkout activity
        await storage.createActivity({
          action: "checkout",
          itemType: "asset",
          itemId: asset.id,
          userId: req.user.id,
          timestamp: new Date().toISOString(),
          notes: customNotes,
        });
      }

      return res.status(201).json(updatedAsset);
    } catch (error) {
      console.error("Error creating asset:", error);
      res.status(500).json({ message: "Failed to create asset" });
    }
  });

  app.patch("/api/assets/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const existingAsset = await storage.getAsset(id);
      if (!existingAsset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      // Validate update data
      const updateData = insertAssetSchema.partial().parse(req.body);

      // Check if asset tag is being changed and if it's unique
      if (updateData.assetTag && updateData.assetTag !== existingAsset.assetTag) {
        const assetWithSameTag = await storage.getAssetByTag(updateData.assetTag);
        if (assetWithSameTag) {
          return res.status(409).json({ message: "Asset tag already exists" });
        }
      }

      // Update the asset
      const updatedAsset = await storage.updateAsset(id, updateData);

      // Log activity
      await storage.createActivity({
        action: "update",
        itemType: "asset",
        itemId: id,
        userId: req.user.id,
        timestamp: new Date().toISOString(),
        notes: `Asset ${updatedAsset?.name} (${updatedAsset?.assetTag}) updated`,
      });

      // Check if the Knox ID was added or updated and the asset isn't already checked out
      if (
        updateData.knoxId &&
        updateData.knoxId.trim() !== '' &&
        (
          !existingAsset.knoxId ||
          updateData.knoxId !== existingAsset.knoxId ||
          existingAsset.status !== 'deployed'
        )
      ) {
        // Automatically checkout the asset if Knox ID changed or added
        const customNotes = `Asset automatically checked out to KnoxID: ${updateData.knoxId}`;
        const checkedOutAsset = await storage.checkoutAsset(id, 1, undefined, customNotes);

        if (checkedOutAsset) {
          // Log checkout activity
          await storage.createActivity({
            action: "checkout",
            itemType: "asset",
            itemId: id,
            userId: 1,
            timestamp: new Date().toISOString(),
            notes: customNotes,
          });

          return res.json(checkedOutAsset);
        }
      }

      return res.json(updatedAsset);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.delete("/api/assets/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const existingAsset = await storage.getAsset(id);
      if (!existingAsset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      await storage.deleteAsset(id);

      // Log activity
      await storage.createActivity({
        action: "delete",
        itemType: "asset",
        itemId: id,
        userId: req.user.id,
        timestamp: new Date().toISOString(),
        notes: `Asset ${existingAsset.name} (${existingAsset.assetTag}) deleted`,
      });

      return res.status(204).send();
    } catch (err) {
      return handleError(err, res);
    }
  });

  // CSV Import API with upsert logic
  app.post("/api/assets/import", async (req: Request, res: Response) => {
    try {
      const { assets, forceImport = false } = req.body;

      if (!Array.isArray(assets)) {
        return res.status(400).json({
          message: "Invalid request format. Expected an array of assets.",
          total: 0,
          successful: 0,
          failed: 0,
          errors: ["Request body must contain an 'assets' array"]
        });
      }

      if (assets.length === 0) {
        return res.status(400).json({
          message: "No assets to import",
          total: 0,
          successful: 0,
          failed: 0,
          errors: ["No assets provided in the request"]
        });
      }

      // Import each asset with error tracking and upsert logic
      // No limit on import quantity - process all assets
      const importedAssets = [];
      const errors = [];
      const skippedRows = [];
      let successful = 0;
      let updated = 0;
      let failed = 0;
      let skipped = 0;

      console.log(`Starting bulk import of ${assets.length} assets${forceImport ? ' [FORCE IMPORT MODE - Skip validations]' : '...'}`);
      console.log(`First asset sample:`, JSON.stringify(assets[0], null, 2));
      console.log(`Last asset sample:`, JSON.stringify(assets[assets.length - 1], null, 2));

      for (let i = 0; i < assets.length; i++) {
        try {
          const asset = assets[i];
          const rowNumber = i + 1;

          console.log(`Processing row ${rowNumber}/${assets.length}:`, {
            assetTag: asset.assetTag,
            name: asset.name,
            serialNumber: asset.serialNumber,
            category: asset.category
          });

          // Skip completely empty assets (all fields are null/empty/undefined)
          const hasData = Object.values(asset).some(value =>
            value !== null && value !== undefined && value !== ''
          );

          if (!hasData) {
            console.log(`Skipping empty row ${rowNumber}`);
            skippedRows.push(`Row ${rowNumber}: Completely empty`);
            skipped++;
            continue;
          }

          // Check for existing asset by asset tag only (skip if force import is enabled)
          let existingAsset = null;

          if (!forceImport) {
            // Check by asset tag if provided
            if (asset.assetTag && asset.assetTag.trim() !== '') {
              existingAsset = await storage.getAssetByTag(asset.assetTag);
              if (existingAsset) {
                console.log(`Found existing asset by tag ${asset.assetTag} (Row ${rowNumber})`);
              }
            }
          }

          if (existingAsset && !forceImport) {
            // Update existing asset (only if not force importing)
            const updateData = {
              ...asset,
              notes: `Updated via CSV import. KnoxID: ${asset.knoxId || 'N/A'}`
            };

            console.log(`Updating existing asset ${existingAsset.id} (Row ${rowNumber})`);
            const updatedAsset = await storage.updateAsset(existingAsset.id, updateData);

            // Create activity for the update
            await storage.createActivity({
              action: "update",
              itemType: "asset",
              itemId: existingAsset.id,
              userId: 1,
              timestamp: new Date().toISOString(),
              notes: `Updated via CSV import. Asset Tag: ${asset.assetTag}, Serial: ${asset.serialNumber}`,
            });

            // Handle Knox ID checkout logic if asset was updated with Knox ID
            if (asset.knoxId && asset.knoxId.trim() !== '' &&
              (updatedAsset?.status !== 'deployed' || updatedAsset?.knoxId !== asset.knoxId)) {
              const customNotes = `Asset automatically checked out to KnoxID: ${asset.knoxId}`;
              const checkedOutAsset = await storage.checkoutAsset(existingAsset.id, 1, undefined, customNotes);

              if (checkedOutAsset) {
                await storage.createActivity({
                  action: "checkout",
                  itemType: "asset",
                  itemId: existingAsset.id,
                  userId: 1,
                  timestamp: new Date().toISOString(),
                  notes: customNotes,
                });
              }
            }

            importedAssets.push(updatedAsset);
            updated++;
            console.log(`Successfully updated asset (Row ${rowNumber}). Total updated: ${updated}`);
          } else {
            // Create new asset (always create if force importing, even if duplicate exists)
            console.log(`Creating new asset (Row ${rowNumber})${forceImport ? ' [FORCE IMPORT]' : ''}`);

            // If force importing and we have a duplicate asset tag, modify it to make it unique
            if (forceImport && existingAsset && asset.assetTag) {
              asset.assetTag = `${asset.assetTag}-${Date.now()}`;
              console.log(`Modified asset tag to avoid duplicate: ${asset.assetTag}`);
            }

            const newAsset = await storage.createAsset(asset);

            // Create activity for the import
            await storage.createActivity({
              action: "create",
              itemType: "asset",
              itemId: newAsset.id,
              userId: req.user?.id || 1,
              timestamp: new Date().toISOString(),
              notes: `Created via CSV import${forceImport ? ' [FORCE IMPORT]' : ''}. KnoxID: ${asset.knoxId || 'N/A'}`,
            });

            // Handle Knox ID checkout logic for new assets
            if (asset.knoxId && asset.knoxId.trim() !== '') {
              const customNotes = `Asset automatically checked out to KnoxID: ${asset.knoxId}`;
              const checkedOutAsset = await storage.checkoutAsset(newAsset.id, 1, undefined, customNotes);

              if (checkedOutAsset) {
                await storage.createActivity({
                  action: "checkout",
                  itemType: "asset",
                  itemId: newAsset.id,
                  userId: 1,
                  timestamp: new Date().toISOString(),
                  notes: customNotes,
                });
              }
            }

            importedAssets.push(newAsset);
            successful++;
            console.log(`Successfully created asset ${newAsset.id} (Row ${rowNumber}). Total created: ${successful}`);
          }
        } catch (assetError) {
          failed++;
          const errorMessage = `Row ${rowNumber}: ${assetError instanceof Error ? assetError.message : 'Unknown error'}`;
          errors.push(errorMessage);
          console.error(`Asset import error:`, errorMessage, asset);
        }
      }

      console.log(`Import summary: Total: ${assets.length}, Created: ${successful}, Updated: ${updated}, Failed: ${failed}, Skipped: ${skipped}`);
      console.log(`Processed: ${successful + updated + failed + skipped}, Expected: ${assets.length}`);

      const response = {
        total: assets.length,
        successful,
        updated,
        failed,
        skipped,
        processed: successful + updated + failed + skipped,
        errors,
        skippedRows,
        message: `Import completed${forceImport ? ' [FORCE IMPORT]' : ''}. ${successful} assets created, ${updated} assets updated, ${failed} failed, ${skipped} skipped.`
      };

      // Return 200 for partial success, 201 for complete success
      const statusCode = failed > 0 ? 200 : 201;
      return res.status(statusCode).json(response);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Checkout/Checkin API
  app.post("/api/assets/:id/checkout", async (req: Request, res: Response) => {
    try {
      const assetId = parseInt(req.params.id);
      const { userId, knoxId, firstName, lastName, expectedCheckinDate } = req.body;

      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      const user = await storage.getUser(parseInt(userId));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const asset = await storage.getAsset(assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      // Generate custom notes if KnoxID is provided
      let customNotes = "";
      if (knoxId && firstName && lastName) {
        customNotes = `Asset checked out to ${firstName} ${lastName} (KnoxID: ${knoxId})`;
      }

      // First update the asset with the Knox ID if provided
      if (knoxId) {
        await storage.updateAsset(assetId, { knoxId });
      }

      // Then perform the checkout operation
      const updatedAsset = await storage.checkoutAsset(assetId, parseInt(userId), expectedCheckinDate, customNotes);
      if (!updatedAsset) {
        return res.status(400).json({ message: "Asset cannot be checked out" });
      }

      return res.json(updatedAsset);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.post("/api/assets/:id/checkin", async (req: Request, res: Response) => {
    try {
      const assetId = parseInt(req.params.id);

      const asset = await storage.getAsset(assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      const updatedAsset = await storage.checkinAsset(assetId);
      if (!updatedAsset) {
        return res.status(400).json({ message: "Asset cannot be checked in" });
      }

      return res.json(updatedAsset);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Finance update API
  app.post("/api/assets/:id/finance", async (req: Request, res: Response) => {
    try {
      const assetId = parseInt(req.params.id);
      const asset = await storage.getAsset(assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      const { financeUpdated } = req.body;

      const updatedAsset = await storage.updateAsset(assetId, {
        financeUpdated: financeUpdated
      });

      // Create activity log
      await storage.createActivity({
        action: "update",
        itemType: "asset",
        itemId: assetId,
        userId: 1, // Assuming admin id is 1
        timestamp: new Date().toISOString(),
        notes: `Finance status updated to: ${financeUpdated ? 'Updated' : 'Not Updated'}`,
      });

      return res.json(updatedAsset);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Cleanup Knox IDs for assets that are not checked out
  app.post("/api/assets/cleanup-knox", async (req: Request, res: Response) => {
    try {
      const assets = await storage.getAssets();
      const availableAssetsWithKnoxId = assets.filter(asset =>
        (asset.status === AssetStatus.AVAILABLE ||
          asset.status === AssetStatus.PENDING ||
          asset.status === AssetStatus.ARCHIVED) &&
        asset.knoxId
      );

      const updates = await Promise.all(
        availableAssetsWithKnoxId.map(asset =>
          storage.updateAsset(asset.id, { knoxId: null })
        )
      );

      // Log activity
      await storage.createActivity({
        action: "update",
        itemType: "asset",
        itemId: 0,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `Cleaned up Knox IDs for ${updates.length} assets that were not checked out`,
      });

      return res.json({
        message: `Cleaned up Knox IDs for ${updates.length} assets`,
        count: updates.length,
        updatedAssets: updates
      });
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Licenses API
  app.get("/api/licenses", checkPermission('licenses', 'view'), async (req: Request, res: Response) => {
    try {
      const licenses = await storage.getLicenses();
      return res.json(licenses);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.get("/api/licenses/:id", checkPermission('licenses', 'view'), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const license = await storage.getLicense(id);
      if (!license) {
        return res.status(404).json({ message: "License not found" });
      }
      return res.json(license);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.post("/api/licenses", checkPermission('licenses', 'add'), async (req: Request, res: Response) => {
    try {
      const licenseData = insertLicenseSchema.parse(req.body);
      const license = await storage.createLicense(licenseData);

      return res.status(201).json(license);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.patch("/api/licenses/:id", checkPermission('licenses', 'edit'), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const existingLicense = await storage.getLicense(id);
      if (!existingLicense) {
        return res.status(404).json({ message: "License not found" });
      }

      // Validate update data
      const updateData = insertLicenseSchema.partial().parse(req.body);

      // Auto-update status based on assigned seats and expiration date
      if (updateData.assignedSeats !== undefined || updateData.expirationDate !== undefined) {
        const expirationDate = updateData.expirationDate || existingLicense.expirationDate;
        const assignedSeats = updateData.assignedSeats !== undefined ? updateData.assignedSeats : existingLicense.assignedSeats || 0;

        // If expiration date passed, set to EXPIRED
        if (expirationDate && new Date(expirationDate) < new Date()) {
          updateData.status = LicenseStatus.EXPIRED;
        }
        // If there are assigned seats, set to ACTIVE (unless expired)
        else if (assignedSeats > 0 && (!updateData.status || updateData.status !== LicenseStatus.EXPIRED)) {
          updateData.status = LicenseStatus.ACTIVE;
        }
        // If no seats are assigned and it's not expired, set to UNUSED
        else if (assignedSeats === 0 && (!updateData.status || updateData.status !== LicenseStatus.EXPIRED)) {
          updateData.status = LicenseStatus.UNUSED;
        }
      }

      const updatedLicense = await storage.updateLicense(id, updateData);

      // Log activity
      await storage.createActivity({
        action: "update",
        itemType: "license",
        itemId: id,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `License "${updatedLicense?.name}" updated`
      });

      return res.json(updatedLicense);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Get all license assignments for a specific license
  app.get("/api/licenses/:id/assignments", async (req: Request, res: Response) => {
    try {
      const licenseId = parseInt(req.params.id);
      const assignments = await storage.getLicenseAssignments(licenseId);
      res.json(assignments);
    } catch (error) {
      handleError(error, res);
    }
  });

  // Assign a license seat
  app.post("/api/licenses/:id/assign", async (req: Request, res: Response) => {
    try {
      const licenseId = parseInt(req.params.id);
      const { assignedTo, notes } = req.body;

      // 1. Get the license
      const license = await storage.getLicense(licenseId);
      if (!license) {
        return res.status(404).json({ error: "License not found" });
      }

      // 2. Check if there are available seats
      if (license.seats && license.seats !== 'Unlimited') {
        const totalSeats = parseInt(license.seats);
        if ((license.assignedSeats || 0) >= totalSeats) {
          return res.status(400).json({ error: "No available seats for this license" });
        }
      }

      // 3. Create assignment
      const assignment = await storage.createLicenseAssignment({
        licenseId,
        assignedTo,
        notes,
        assignedDate: new Date().toISOString()
      });

      // 4. Update license assignedSeats count
      let status = license.status;
      // Auto-update status based on new assignment and expiration date
      if (license.expirationDate && new Date(license.expirationDate) < new Date()) {
        status = LicenseStatus.EXPIRED;
      } else {
        status = LicenseStatus.ACTIVE; // Since we're adding a seat, it's now active
      }

      const updatedLicense = await storage.updateLicense(licenseId, {
        assignedSeats: (license.assignedSeats || 0) + 1,
        status
      });

      // Log activity
      await storage.createActivity({
        action: "update",
        itemType: "license",
        itemId: licenseId,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `License seat assigned to: ${assignedTo}`
      });

      res.status(201).json({ assignment, license: updatedLicense });
    } catch (error) {
      handleError(error, res);
    }
  });

  app.delete("/api/licenses/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const existingLicense = await storage.getLicense(id);
      if (!existingLicense) {
        return res.status(404).json({ message: "License not found" });
      }

      await storage.deleteLicense(id);

      return res.status(204).send();
    } catch (err) {
      return handleError(err, res);
    }
  });

  // IT Equipment API
  app.get("/api/it-equipment", requireAuth, async (req: Request, res: Response) => {
    try {
      console.log('IT Equipment API called by user:', req.user?.username);

      if (!db) {
        return res.status(503).json({
          message: "Database not available. Please configure DATABASE_URL environment variable."
        });
      }

      const equipment = await db.select().from(schema.itEquipment).orderBy(schema.itEquipment.id);
      console.log(`Found ${equipment.length} IT equipment items`);

      // Calculate assigned quantities for each equipment
      const equipmentWithAssignments = await Promise.all(equipment.map(async (item) => {
        try {
          const assignments = await db.select()
            .from(schema.itEquipmentAssignments)
            .where(eq(schema.itEquipmentAssignments.equipmentId, item.id));

          const calculatedAssignedQuantity = assignments
            .filter(a => a.status === 'assigned')
            .reduce((sum, a) => sum + (a.quantity || 0), 0);

          // Use the calculated quantity if it differs from stored quantity
          const finalAssignedQuantity = calculatedAssignedQuantity;

          console.log(`Equipment ${item.name}: stored=${item.assignedQuantity}, calculated=${calculatedAssignedQuantity}`);

          // Update the stored assigned quantity if it's different
          if (item.assignedQuantity !== calculatedAssignedQuantity) {
            await db.update(schema.itEquipment)
              .set({
                assignedQuantity: calculatedAssignedQuantity,
                updatedAt: new Date().toISOString()
              })
              .where(eq(schema.itEquipment.id, item.id));
          }

          return {
            ...item,
            assignedQuantity: finalAssignedQuantity
          };
        } catch (assignmentError) {
          console.error(`Error calculating assignments for equipment ${item.id}:`, assignmentError);
          return {
            ...item,
            assignedQuantity: item.assignedQuantity || 0
          };
        }
      }));

      res.json(equipmentWithAssignments);
    } catch (error) {
      console.error("Error fetching IT equipment:", error);
      res.status(500).json({
        message: "Failed to fetch IT equipment",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/it-equipment/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);

      if (!db) {
        return res.status(503).json({
          message: "Database not available"
        });
      }

      const [equipment] = await db.select()
        .from(schema.itEquipment)
        .where(eq(schema.itEquipment.id, id));

      if (!equipment) {
        return res.status(404).json({ message: "IT Equipment not found" });
      }

      // Get assignments for this equipment
      const assignments = await db.select()
        .from(schema.itEquipmentAssignments)
        .where(eq(schema.itEquipmentAssignments.equipmentId, id));

      const assignedQuantity = assignments
        .filter(a => a.status === 'assigned')
        .reduce((sum, a) => sum + (a.quantity || 0), 0);

      res.json({
        ...equipment,
        assignedQuantity,
        assignments
      });
    } catch (error) {
      console.error("Error fetching IT equipment:", error);
      res.status(500).json({ message: "Failed to fetch IT equipment" });
    }
  });

  app.post("/api/it-equipment", requireAuth, async (req: Request, res: Response) => {
    try {
      const equipmentData = req.body;
      console.log('Creating IT equipment with data:', equipmentData);

      if (!db) {
        return res.status(503).json({
          message: "Database not available"
        });
      }

      // Validate required fields
      if (!equipmentData.name || !equipmentData.category || !equipmentData.totalQuantity) {
        return res.status(400).json({
          message: "Name, category, and total quantity are required"
        });
      }

      const newEquipment = {
        name: equipmentData.name.trim(),
        category: equipmentData.category.trim(),
        totalQuantity: parseInt(equipmentData.totalQuantity),
        assignedQuantity: 0,
        model: equipmentData.model?.trim() || null,
        location: equipmentData.location?.trim() || null,
        dateAcquired: equipmentData.dateAcquired || null,
        knoxId: equipmentData.knoxId?.trim() || null,
        serialNumber: equipmentData.serialNumber?.trim() || null,
        dateRelease: equipmentData.dateRelease || null,
        remarks: equipmentData.remarks?.trim() || null,
        status: equipmentData.status || 'available',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const [equipment] = await db.insert(schema.itEquipment)
        .values(newEquipment)
        .returning();

      // Log activity
      await storage.createActivity({
        action: "create",
        itemType: "it-equipment",
        itemId: equipment.id,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `IT Equipment "${equipment.name}" created`,
      });

      console.log('IT Equipment created successfully:', equipment);
      res.status(201).json(equipment);
    } catch (error) {
      console.error("Error creating IT equipment:", error);
      res.status(500).json({
        message: "Failed to create IT equipment",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.patch("/api/it-equipment/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const equipmentData = req.body;

      if (!db) {
        return res.status(503).json({
          message: "Database not available"
        });
      }

      const updateData = {
        name: equipmentData.name?.trim(),
        category: equipmentData.category?.trim(),
        totalQuantity: equipmentData.totalQuantity ? parseInt(equipmentData.totalQuantity) : undefined,
        model: equipmentData.model?.trim() || null,
        location: equipmentData.location?.trim() || null,
        dateAcquired: equipmentData.dateAcquired || null,
        knoxId: equipmentData.knoxId?.trim() || null,
        serialNumber: equipmentData.serialNumber?.trim() || null,
        dateRelease: equipmentData.dateRelease || null,
        remarks: equipmentData.remarks?.trim() || null,
        status: equipmentData.status,
        updatedAt: new Date().toISOString()
      };

      // Remove undefined values
      const cleanUpdateData = {};
      Object.keys(updateData).forEach(key => {
        if (updateData[key] !== undefined) {
          cleanUpdateData[key] = updateData[key];
        }
      });

      const [equipment] = await db.update(schema.itEquipment)
        .set(cleanUpdateData)
        .where(eq(schema.itEquipment.id, id))
        .returning();

      if (!equipment) {
        return res.status(404).json({ message: "IT Equipment not found" });
      }

      // Log activity
      await storage.createActivity({
        action: "update",
        itemType: "it-equipment",
        itemId: id,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `IT Equipment "${equipment.name}" updated`,
      });

      res.json(equipment);
    } catch (error) {
      console.error("Error updating IT equipment:", error);
      res.status(500).json({ message: "Failed to update IT equipment" });
    }
  });

  app.delete("/api/it-equipment/:id", requireAuth, async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);

      if (!db) {
        return res.status(503).json({
          message: "Database not available"
        });
      }

      // Get equipment info before deletion
      const [equipment] = await db.select()
        .from(schema.itEquipment)
        .where(eq(schema.itEquipment.id, id));

      if (!equipment) {
        return res.status(404).json({ message: "IT Equipment not found" });
      }

      // Delete assignments first
      await db.delete(schema.itEquipmentAssignments)
        .where(eq(schema.itEquipmentAssignments.equipmentId, id));

      // Delete equipment
      await db.delete(schema.itEquipment)
        .where(eq(schema.itEquipment.id, id));

      // Log activity
      await storage.createActivity({
        action: "delete",
        itemType: "it-equipment",
        itemId: id,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `IT Equipment "${equipment.name}" deleted`,
      });

      res.status(204).send();
    } catch (error) {
      console.error("Error deleting IT equipment:", error);
      res.status(500).json({ message: "Failed to delete IT equipment" });
    }
  });

  app.post("/api/it-equipment/import", requireAuth, async (req: Request, res: Response) => {
    try {
      const { equipment } = req.body;

      if (!Array.isArray(equipment)) {
        return res.status(400).json({
          message: "Invalid request format. Expected an array of equipment.",
          total: 0,
          successful: 0,
          failed: 0,
          errors: ["Request body must contain an 'equipment' array"]
        });
      }

      if (!db) {
        return res.status(503).json({
          message: "Database not available"
        });
      }

      let successful = 0;
      let failed = 0;
      const errors = [];

      console.log(`Starting import of ${equipment.length} IT equipment items...`);

      for (let i = 0; i < equipment.length; i++) {
        try {
          const item = equipment[i];
          const rowNumber = i + 1;

          console.log(`Processing equipment row ${rowNumber}:`, item);

          if (!item.name || !item.category || !item.totalQuantity) {
            throw new Error(`Row ${rowNumber}: Name, category, and total quantity are required`);
          }

          // Parse assignment data
          const hasAssignment = item.assignedTo && item.assignedTo.trim() !== '' && item.assignedTo !== '-';
          const assignmentQuantity = hasAssignment ? parseInt(item.assignedQuantity || '1') : 0;

          const newEquipment = {
            name: item.name.trim(),
            category: item.category.trim(),
            totalQuantity: parseInt(item.totalQuantity),
            assignedQuantity: assignmentQuantity, // Set correct assigned quantity
            model: item.model?.trim() || null,
            location: item.location?.trim() || null,
            dateAcquired: item.dateAcquired || null,
            knoxId: item.knoxId?.trim() || null,
            serialNumber: item.serialNumber?.trim() || null,
            dateRelease: item.dateRelease || null,
            remarks: item.remarks?.trim() || null,
            status: item.status || 'available',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString()
          };

          console.log(`Creating equipment with data:`, newEquipment);

          const [createdEquipment] = await db.insert(schema.itEquipment).values(newEquipment).returning();

          // Create assignment if assignment data exists
          if (hasAssignment && assignmentQuantity > 0) {
            const assignmentData = {
              equipmentId: createdEquipment.id,
              assignedTo: item.assignedTo.trim(),
              knoxId: item.assignmentKnoxId?.trim() || item.knoxId?.trim() || null,
              serialNumber: item.assignmentSerialNumber?.trim() || item.serialNumber?.trim() || null,
              quantity: assignmentQuantity,
              assignedDate: item.assignedDate || new Date().toISOString(),
              status: 'assigned',
              notes: item.assignmentNotes?.trim() || null
            };

            console.log(`Creating assignment with data:`, assignmentData);

            await db.insert(schema.itEquipmentAssignments).values(assignmentData);

            // Log assignment activity
            await storage.createActivity({
              action: "assign",
              itemType: "it-equipment",
              itemId: createdEquipment.id,
              userId: req.user?.id || 1,
              timestamp: new Date().toISOString(),
              notes: `IT Equipment imported with assignment to ${item.assignedTo} (Qty: ${assignmentQuantity})`,
            });

            console.log(`Assignment created successfully for ${item.assignedTo}`);
          }

          // Log equipment creation
          await storage.createActivity({
            action: "create",
            itemType: "it-equipment",
            itemId: createdEquipment.id,
            userId: req.user?.id || 1,
            timestamp: new Date().toISOString(),
            notes: `IT Equipment "${createdEquipment.name}" imported via CSV${hasAssignment ? ' with assignment' : ''}`,
          });

          successful++;
          console.log(`Successfully processed equipment row ${rowNumber}: ${item.name}`);
        } catch (itemError) {
          failed++;
          const errorMessage = `Row ${i + 1}: ${itemError.message}`;
          errors.push(errorMessage);
          console.error(`Equipment import error:`, errorMessage, item);
        }
      }

      console.log(`Import completed. Successful: ${successful}, Failed: ${failed}`);

      const response = {
        total: equipment.length,
        successful,
        failed,
        errors,
        message: `Import completed. ${successful} equipment items imported, ${failed} failed.`
      };

      const statusCode = failed > 0 ? 200 : 201;
      return res.status(statusCode).json(response);
    } catch (error) {
      console.error("IT Equipment import error:", error);
      return res.status(500).json({
        message: "Import failed",
        error: error.message
      });
    }
  });

  // IT Equipment Assignment routes
  app.get("/api/it-equipment/:id/assignments", requireAuth, async (req: Request, res: Response) => {
    try {
      const equipmentId = parseInt(req.params.id);

      if (!db) {
        return res.status(503).json({
          message: "Database not available"
        });
      }

      const assignments = await db.select()
        .from(schema.itEquipmentAssignments)
        .where(eq(schema.itEquipmentAssignments.equipmentId, equipmentId))
        .orderBy(schema.itEquipmentAssignments.assignedDate);

      res.json(assignments);
    } catch (error) {
      console.error("Error fetching IT equipment assignments:", error);
      res.status(500).json({ message: "Failed to fetch IT equipment assignments" });
    }
  });

  app.post("/api/it-equipment/:id/assign", requireAuth, async (req: Request, res: Response) => {
    try {
      const equipmentId = parseInt(req.params.id);
      const assignmentData = req.body;

      console.log('IT Equipment assignment request:', { equipmentId, assignmentData });

      if (!db) {
        return res.status(503).json({
          message: "Database not available"
        });
      }

      // Validate required fields
      if (!assignmentData.assignedTo) {
        return res.status(400).json({
          message: "assignedTo is required"
        });
      }

      // Get equipment to check availability
      const [equipment] = await db.select()
        .from(schema.itEquipment)
        .where(eq(schema.itEquipment.id, equipmentId));

      if (!equipment) {
        return res.status(404).json({ message: "IT Equipment not found" });
      }

      console.log('Current equipment state:', equipment);

      const totalQuantity = equipment.totalQuantity || 0;
      const currentAssignedQuantity = equipment.assignedQuantity || 0;
      const availableQuantity = totalQuantity - currentAssignedQuantity;
      const requestedQuantity = parseInt(assignmentData.quantity) || 1;

      console.log('Quantity check:', { totalQuantity, currentAssignedQuantity, availableQuantity, requestedQuantity });

      if (requestedQuantity > availableQuantity) {
        return res.status(400).json({
          message: `Not enough units available. Requested: ${requestedQuantity}, Available: ${availableQuantity}`
        });
      }

      // Create assignment record
      const [assignment] = await db.insert(schema.itEquipmentAssignments).values({
        equipmentId,
        assignedTo: assignmentData.assignedTo,
        knoxId: assignmentData.knoxId || null,
        serialNumber: assignmentData.serialNumber || null,
        quantity: requestedQuantity,
        assignedDate: assignmentData.assignedDate || new Date().toISOString(),
        status: 'assigned',
        notes: assignmentData.notes || null
      }).returning();

      console.log('Assignment created:', assignment);

      // Update equipment assigned quantity
      const newAssignedQuantity = currentAssignedQuantity + requestedQuantity;
      const [updatedEquipment] = await db.update(schema.itEquipment)
        .set({
          assignedQuantity: newAssignedQuantity,
          updatedAt: new Date().toISOString()
        })
        .where(eq(schema.itEquipment.id, equipmentId))
        .returning();

      console.log('Equipment updated:', updatedEquipment);

      // Log activity
      await storage.createActivity({
        action: "assign",
        itemType: "it-equipment",
        itemId: equipmentId,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `IT Equipment assigned to ${assignmentData.assignedTo} (Qty: ${requestedQuantity})`,
      });

      // Return the assignment with updated equipment info
      res.status(201).json({
        assignment,
        updatedEquipment
      });
    } catch (error) {
      console.error("Error assigning IT equipment:", error);
      res.status(500).json({
        message: "Failed to assign IT equipment",
        error: error.message
      });
    }
  });

  app.post("/api/it-equipment/bulk-assign", requireAuth, async (req: Request, res: Response) => {
    try {
      const equipmentId = parseInt(req.params.id);
      const { assignments } = req.body;

      console.log('Bulk assignment request:', { equipmentId, assignments });

      if (!db) {
        return res.status(503).json({
          message: "Database not available"
        });
      }

      if (!Array.isArray(assignments) || assignments.length === 0) {
        return res.status(400).json({
          message: "assignments array is required"
        });
      }

      // Get equipment to check availability
      const [equipment] = await db.select()
        .from(schema.itEquipment)
        .where(eq(schema.itEquipment.id, equipmentId));

      if (!equipment) {
        return res.status(404).json({ message: "IT Equipment not found" });
      }

      console.log('Equipment found:', equipment);

      const totalQuantity = equipment.totalQuantity || 0;
      const assignedQuantity = equipment.assignedQuantity || 0;
      const availableQuantity = totalQuantity - assignedQuantity;
      const totalRequestedQuantity = assignments.reduce((sum, a) => sum + (parseInt(a.quantity) || 1), 0);

      console.log('Quantity validation:', { totalQuantity, assignedQuantity, availableQuantity, totalRequestedQuantity });

      if (totalRequestedQuantity > availableQuantity) {
        return res.status(400).json({
          message: `Not enough units available. Requested: ${totalRequestedQuantity}, Available: ${availableQuantity}`
        });
      }

      const createdAssignments = [];

      // Create all assignments
      for (const assignmentData of assignments) {
        if (!assignmentData.assignedTo) {
          return res.status(400).json({
            message: "assignedTo is required for all assignments"
          });
        }

        console.log('Creating assignment:', assignmentData);

        const [assignment] = await db.insert(schema.itEquipmentAssignments).values({
          equipmentId,
          assignedTo: assignmentData.assignedTo,
          knoxId: assignmentData.knoxId || null,
          serialNumber: assignmentData.serialNumber || null,
          quantity: parseInt(assignmentData.quantity) || 1,
          assignedDate: assignmentData.assignedDate || new Date().toISOString(),
          status: 'assigned',
          notes: assignmentData.notes || null
        }).returning();

        console.log('Assignment created:', assignment);
        createdAssignments.push(assignment);

        // Log activity for each assignment
        await storage.createActivity({
          action: "assign",
          itemType: "it-equipment",
          itemId: equipmentId,
          userId: req.user?.id || 1,
          timestamp: new Date().toISOString(),
          notes: `IT Equipment assigned to ${assignmentData.assignedTo} (Qty: ${parseInt(assignmentData.quantity) || 1})`,
        });
      }

      // Update equipment assigned quantity
      const newAssignedQuantity = assignedQuantity + totalRequestedQuantity;
      const [updatedEquipment] = await db.update(schema.itEquipment)
        .set({
          assignedQuantity: newAssignedQuantity,
          updatedAt: new Date().toISOString()
        })
        .where(eq(schema.itEquipment.id, equipmentId))
        .returning();

      console.log('Equipment updated with new assigned quantity:', updatedEquipment);

      res.status(201).json({
        message: `Successfully created ${createdAssignments.length} assignments`,
        assignments: createdAssignments,
        updatedEquipment
      });
    } catch (error) {
      console.error("Error in bulk assignment:", error);
      res.status(500).json({
        message: "Failed to create bulk assignments",
        error: error.message
      });
    }
  });

  // Remove IT equipment assignment
  app.delete("/api/it-equipment/assignments/:assignmentId", requireAuth, async (req: Request, res: Response) => {
    try {
      const assignmentId = parseInt(req.params.assignmentId);

      if (!db) {
        return res.status(503).json({
          message: "Database not available"
        });
      }

      // Get assignment details before deletion
      const [assignment] = await db.select()
        .from(schema.itEquipmentAssignments)
        .where(eq(schema.itEquipmentAssignments.id, assignmentId));

      if (!assignment) {
        return res.status(404).json({ message: "Assignment not found" });
      }

      // Get equipment to update assigned quantity
      const [equipment] = await db.select()
        .from(schema.itEquipment)
        .where(eq(schema.itEquipment.id, assignment.equipmentId));

      if (!equipment) {
        return res.status(404).json({ message: "Equipment not found" });
      }

      // Delete the assignment
      await db.delete(schema.itEquipmentAssignments)
        .where(eq(schema.itEquipmentAssignments.id, assignmentId));

      // Update equipment assigned quantity
      const currentAssignedQuantity = equipment.assignedQuantity || 0;
      const newAssignedQuantity = Math.max(0, currentAssignedQuantity - (assignment.quantity || 1));

      await db.update(schema.itEquipment)
        .set({
          assignedQuantity: newAssignedQuantity,
          updatedAt: new Date().toISOString()
        })
        .where(eq(schema.itEquipment.id, assignment.equipmentId));

      // Log activity
      await storage.createActivity({
        action: "unassign",
        itemType: "it-equipment",
        itemId: assignment.equipmentId,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `IT Equipment assignment removed for ${assignment.assignedTo} (Qty: ${assignment.quantity})`,
      });

      res.status(204).send();
    } catch (error) {
      console.error("Error removing IT equipment assignment:", error);
      res.status(500).json({ message: "Failed to remove assignment" });
    }
  });

  // Activities API
  app.get("/api/activities", async (req: Request, res: Response) => {
    try {
      const activities = await storage.getActivities();
      return res.json(activities);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.get("/api/users/:id/activities", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const activities = await storage.getActivitiesByUser(userId);
      return res.json(activities);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.get("/api/assets/:id/activities", async (req: Request, res: Response) => {
    try {
      const assetId = parseInt(req.params.id);
      const asset = await storage.getAsset(assetId);
      if (!asset) {
        return res.status(404).json({ message: "Asset not found" });
      }

      const activities = await storage.getActivitiesByAsset(assetId);
      return res.json(activities);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Components API
  app.get("/api/components", checkPermission('components', 'view'), async (req: Request, res: Response) => {
    try {
      const components = await storage.getComponents();
      return res.json(components);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.get("/api/components/:id", checkPermission('components', 'view'), async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const component = await storage.getComponent(id);
      if (!component) {
        return res.status(404).json({ message: "Component not found" });
      }
      return res.json(component);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.post("/api/components", checkPermission('components', 'add'), async (req: Request, res: Response) => {
    try {
      console.log('Creating component with data:', req.body);

      const componentData = insertComponentSchema.parse(req.body);
      const component = await storage.createComponent(componentData);

      // Log activity
      await storage.createActivity({
        action: "create",
        itemType: "component",
        itemId: component.id,
        userId: req.user.id,
        timestamp: new Date().toISOString(),
        notes: `Created component: ${component.name}`,
      });

      console.log('Component created successfully:', component);
      return res.status(201).json(component);
    } catch (err) {
      console.error('Error creating component:', err);
      return handleError(err, res);
    }
  });

  app.patch("/api/components/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;

      const component = await storage.updateComponent(id, updates);

      if (!component) {
        return res.status(404).json({ message: "Component not found" });
      }

      // Log activity
      await storage.createActivity({
        action: "update",
        itemType: "component",
        itemId: id,
        userId: 1, // Default user for now
        timestamp: new Date().toISOString(),
        notes: `Updated component: ${component.name}`,
      });

      return res.json(component);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.delete("/api/components/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const existingComponent = await storage.getComponent(id);
      if (!existingComponent) {
        return res.status(404).json({ message: "Component not found" });
      }

      await storage.deleteComponent(id);

      // Log activity
      await storage.createActivity({
        action: "delete",
        itemType: "component",
        itemId: id,
        userId: 1, // Default user for now
        timestamp: new Date().toISOString(),
        notes: `Deleted component: ${existingComponent.name}`,
      });

      return res.status(204).send();
    } catch (err) {
      return handleError(err, res);
    }
  });

  // VM Monitoring API - Add or update VM monitoring data
  app.post("/api/vm-monitoring", async (req: Request, res: Response) => {
    try {
      const monitoringData = insertVMMonitoringSchema.parse(req.body);

      // Check if VM monitoring data already exists
      const existingData = await storage.getVMMonitoringByVMId(monitoringData.vmId);

      let result;
      if (existingData) {
        // Update existing data
        result = await storage.updateVMMonitoring(existingData.id, monitoringData);
      } else {
        // Create new data
        result = await storage.createVMMonitoring(monitoringData);
      }

      return res.status(201).json(result);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // VM Monitoring API - Manual sync with Zabbix
  app.post("/api/vm-monitoring/sync", async (req: Request, res: Response) => {
    try {
      const settings = await storage.getZabbixSettings();
      if (!settings || !settings.url || !settings.username || !settings.password) {
        return res.status(400).json({ message: "Zabbix connection not configured" });
      }

      // Authenticate with Zabbix API
      const authResponse = await makeZabbixApiCall(settings.url, settings.username, settings.password, 'user.login');

      if (authResponse.error) {
        throw new Error(`Zabbix authentication failed: ${authResponse.error.message}`);
      }

      const authToken = authResponse.result;

      // Get hosts to sync
      const hostsResponse = await makeZabbixApiCall(settings.url, settings.username, settings.password, 'host.get', {
        output: ['hostid', 'host', 'name', 'status', 'available'],
        selectItems: ['key_', 'lastvalue', 'units'],
        selectInterfaces: ['ip'],
        filter: {
          status: 0 // Only enabled hosts
        }
      }, authToken);

      if (hostsResponse.error) {
        throw new Error(`Failed to fetch hosts: ${hostsResponse.error.message}`);
      }

      let syncedCount = 0;

      // Process and store VM monitoring data
      for (const host of hostsResponse.result) {
        try {
          const cpuItem = host.items?.find((item: any) =>
            item.key_.includes('system.cpu.util') || item.key_.includes('cpu.usage')
          );
          const memoryItem = host.items?.find((item: any) =>
            item.key_.includes('memory.util') || item.key_.includes('vm.memory.util')
          );
          const diskItem = host.items?.find((item: any) =>
            item.key_.includes('vfs.fs.size') && item.key_.includes('pfree')
          );
          const uptimeItem = host.items?.find((item: any) =>
            item.key_.includes('system.uptime')
          );

          const vmData = {
            vmId: parseInt(host.hostid),
            hostname: host.name,
            ipAddress: host.interfaces?.[0]?.ip || host.host,
            status: getVMStatusFromZabbix(host.available),
            cpuUsage: cpuItem ? parseFloat(cpuItem.lastvalue) : null,
            memoryUsage: memoryItem ? parseFloat(memoryItem.lastvalue) : null,
            diskUsage: diskItem ? (100 - parseFloat(diskItem.lastvalue)) : null,
            uptime: uptimeItem ? parseInt(uptimeItem.lastvalue) : null,
            networkStatus: host.available === '1' ? 'up' : 'down',
            updatedAt: new Date().toISOString()
          };

          // Check if VM monitoring data already exists
          const existingData = await storage.getVMMonitoringByVMId(parseInt(host.hostid));

          if (existingData) {
            await storage.updateVMMonitoring(existingData.id, vmData);
          } else {
            await storage.createVMMonitoring(vmData);
          }

          syncedCount++;
        } catch (vmError) {
          console.error(`Error syncing VM ${host.name}:`, vmError);
        }
      }

      // Log activity
      await storage.createActivity({
        action: "sync",
        itemType: "vm-monitoring",
        itemId: 1,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `Synchronized ${syncedCount} VMs from Zabbix`,
      });

      return res.json({
        success: true,
        message: `Sync completed successfully. Synchronized ${syncedCount} VMs.`,
        count: syncedCount
      });
    } catch (err) {
      console.error('VM sync error:', err);
      return handleError(err, res);
    }
  });

  // Helper function to convert Zabbix availability to VM status
  function getVMStatusFromZabbix(available: string | number): string {
    const statusMap: { [key: string]: string } = {
      '0': 'unknown',
      '1': 'running',
      '2': 'stopped'
    };
    return statusMap[available.toString()] || 'unknown';
  }

  // Network Discovery API - Get all discovered hosts
  app.get("/api/network-discovery/hosts", async (req: Request, res: Response) => {
    try {
      const hosts = await storage.getDiscoveredHosts();
      return res.json(hosts);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Network Discovery API - Get specific discovered host
  app.get("/api/network-discovery/hosts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const host = await storage.getDiscoveredHost(id);

      if (!host) {
        return res.status(404).json({ message: "Discovered host not found" });
      }

      return res.json(host);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Network Discovery API - Create discovered host
  app.post("/api/network-discovery/hosts", async (req: Request, res: Response) => {
    try {
      const hostData = insertDiscoveredHostSchema.parse(req.body);
      const host = await storage.createDiscoveredHost(hostData);
      return res.status(201).json(host);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Network Discovery API - Update discovered host
  app.patch("/api/network-discovery/hosts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const host = await storage.getDiscoveredHost(id);

      if (!host) {
        return res.status(404).json({ message: "Discovered host not found" });
      }

      const updateData = insertDiscoveredHostSchema.partial().parse(req.body);
      const updatedHost = await storage.updateDiscoveredHost(id, updateData);

      return res.json(updatedHost);
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Network Discovery API - Delete discovered host
  app.delete("/api/network-discovery/hosts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const host = await storage.getDiscoveredHost(id);

      if (!host) {
        return res.status(404).json({ message: "Discovered host not found" });
      }

      await storage.deleteDiscoveredHost(id);
      return res.status(204).send();
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Network Discovery API - Initiate network scan
  app.post("/api/network-discovery/scan", async (req: Request, res: Response) => {
    try {
      const {
        ipRange,
        primaryDNS,
        secondaryDNS,
        useDNS,
        scanForUSB,
        scanForSerialNumbers,
        scanForHardwareDetails,
        scanForInstalledSoftware,
        zabbixUrl,
        zabbixApiKey,
        useZabbix
      } = req.body;

      if (!ipRange) {
        return res.status(400).json({ message: "IP range is required" });
      }

      // Validate IP range format
      const cidrRegex = /^([0-9]{1,3}\.){3}[0-9]{1,3}(\/([0-9]|[1-2][0-9]|3[0-2]))?$/;
      if (!cidrRegex.test(ipRange)) {
        return res.status(400).json({ message: "Invalid IP range format. Use CIDR notation (e.g., 192.168.1.0/24)" });
      }

      console.log(`Starting real network scan for range: ${ipRange}`);

      // Check if we should use Zabbix settings
      let usingZabbix = false;
      let zabbixInfo = {};

      if (useZabbix && zabbixUrl && zabbixApiKey) {
        usingZabbix = true;
        zabbixInfo = {
          url: zabbixUrl,
          apiKey: zabbixApiKey
        };
        console.log(`Network scan will use Zabbix integration: ${zabbixUrl}`);
      }

      // Prepare DNS settings
      let dnsSettings = null;
      if (useDNS && (primaryDNS || secondaryDNS)) {
        dnsSettings = {
          primaryDNS: primaryDNS || '8.8.8.8',
          secondaryDNS: secondaryDNS || '8.8.4.4'
        };
        console.log(`Network scan will use DNS servers: ${dnsSettings.primaryDNS}, ${dnsSettings.secondaryDNS}`);
      }

      // Send scan initiation response
      const scanDetails = {
        ipRange,
        scanOptions: {
          scanForUSB: scanForUSB || false,
          scanForSerialNumbers: scanForSerialNumbers || false,
          scanForHardwareDetails: scanForHardwareDetails || false,
          scanForInstalledSoftware: scanForInstalledSoftware || false,
          useDNS: useDNS || false
        },
        usingZabbix,
        dnsSettings,
        startTime: new Date().toISOString()
      };

      // Start actual network scanning in background
      startNetworkScan(ipRange, scanDetails, storage);

      // Send immediate response to the client
      return res.json({
        success: true,
        message: "Real network scan initiated. This may take several minutes to complete.",
        scanDetails
      });
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Network Discovery API - Import discovered host as asset
  app.post("/api/network-discovery/hosts/:id/import", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const host = await storage.getDiscoveredHost(id);

      if (!host) {
        return res.status(404).json({ message: "Discovered host not found" });
      }

      // Create asset from discovered host
      const assetData = {
        name: host.hostname || host.ipAddress,
        status: "available",
        assetTag: `DISC-${Date.now()}`,
        category: "computer",
        ipAddress: host.ipAddress,
        macAddress: host.macAddress,
        model: host.hardwareDetails && typeof host.hardwareDetails === 'object' ? host.hardwareDetails.model || null : null,
        manufacturer: host.hardwareDetails && typeof host.hardwareDetails === 'object' ? host.hardwareDetails.manufacturer || null : null,
        osType: host.systemInfo && typeof host.systemInfo === 'object' ? host.systemInfo.os || null : null,
        serialNumber: host.hardwareDetails && typeof host.hardwareDetails === 'object' ? host.hardwareDetails.serialNumber || null : null,
        description: `Imported from network discovery: ${host.ipAddress}`
      };

      const asset = await storage.createAsset(assetData);

      // Update the discovered host status to imported
      await storage.updateDiscoveredHost(id, { status: "imported" });

      // Log the activity
      await storage.createActivity({
        action: "import",
        itemType: "asset",
        itemId: asset.id,
        userId: null,
        timestamp: new Date().toISOString(),
        notes: `Asset imported from discovered host ${host.ipAddress}`
      });

      return res.status(201).json({
        success: true,
        message: "Host successfully imported as asset",
        asset
      });
    } catch (err) {
      return handleError(err, res);
    }
  });

  // Bitlocker Keys API endpoints
  app.get("/api/bitlocker-keys", async (req: Request, res: Response) => {
    try {
      console.log('Fetching BitLocker keys...');

      // Try PostgreSQL first, fallback to memory storage automatically
      const keys = await storage.getBitlockerKeys();

      console.log(`Found ${keys.length} BitLocker keys`);
      return res.json(keys);
    } catch (err) {
      console.error('Error fetching BitLocker keys:', err);
      return handleError(err, res);
    }
  });

  app.get("/api/bitlocker-keys/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const key = await storage.getBitlockerKey(id);

      if (!key) {
        return res.status(404).json({ message: "Bitlocker key not found" });
      }

      return res.json(key);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.get("/api/bitlocker-keys/search/serial/:serialNumber", async (req: Request, res: Response) => {
    try {
      const serialNumber = req.params.serialNumber;
      const keys = await storage.getBitlockerKeyBySerialNumber(serialNumber);
      return res.json(keys);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.get("/api/bitlocker-keys/search/identifier/:identifier", async (req: Request, res: Response) => {
    try {
      const identifier = req.params.identifier;
      const keys = await storage.getBitlockerKeyByIdentifier(identifier);
      return res.json(keys);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.post("/api/bitlocker-keys", async (req: Request, res: Response) => {
    try {
      const { insertBitlockerKeySchema } = schema;
      const data = insertBitlockerKeySchema.parse(req.body);

      console.log('Creating BitLocker key:', data.serialNumber);

      // Use the unified storage layer which handles both DB and memory fallback
      const key = await storage.createBitlockerKey(data);

      console.log('BitLocker key created successfully:', key.id);

      // Log activity
      try {
        await storage.createActivity({
          action: "create",
          itemType: "bitlocker",
          itemId: key.id,
          userId: req.user?.id || 1,
          timestamp: new Date().toISOString(),
          notes: `BitLocker key created for ${data.serialNumber}`,
        });
      } catch (activityError) {
        console.warn('Failed to create activity log:', activityError);
      }

      return res.status(201).json(key);
    } catch (err) {
      console.error('Error creating BitLocker key:', err);

      // Provide specific error handling for database issues
      if (err.message && err.message.includes('Database connection required')) {
        return res.status(503).json({
          message: 'BitLocker key creation requires database connection. Please set up PostgreSQL database.',
          instruction: 'Go to Database tab → Create a database to fix this issue.',
          code: 'DB_CONNECTION_REQUIRED'
        });
      }

      return handleError(err, res);
    }
  });

  app.patch("/api/bitlocker-keys/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const { insertBitlockerKeySchema } = schema;
      const updateData = insertBitlockerKeySchema.partial().parse(req.body);
      const key = await storage.updateBitlockerKey(id, updateData);

      if (!key) {
        return res.status(404).json({ message: "Bitlocker key not found" });
      }

      return res.json(key);
    } catch (err) {
      return handleError(err, res);
    }
  });

  app.delete("/api/bitlocker-keys/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const result = await storage.deleteBitlockerKey(id);

      if (!result) {
        return res.status(404).json({ message: "Bitlocker key not found" });
      }

      return res.json({ message: "Bitlocker key deleted successfully" });
    } catch (err) {
      return handleError(err, res);
    }
  });

  // IAM Accounts routes
  app.get("/api/iam-accounts", async (req: Request, res: Response) => {
    try {
      console.log('Fetching IAM accounts...');

      // Check database connection first
      if (!db) {
        console.error('Database not available');
        return res.status(503).json({
          message: "Database not available",
          data: []
        });
      }

      // Fetch directly from database to ensure we get the data
      const accounts = await db.select().from(schema.iamAccounts).orderBy(schema.iamAccounts.id);
      console.log(`Found ${accounts.length} IAM accounts in database`);

      // Map database fields to frontend expected format
      const mappedAccounts = accounts.map(account => ({
        id: account.id,
        requestor: account.requestor,
        knoxId: account.knoxId,
        permission: account.permission,
        durationStartDate: account.durationStartDate,
        durationEndDate: account.durationEndDate,
        cloudPlatform: account.cloudPlatform,
        projectAccounts: account.projectAccounts,
        approvalId: account.approvalId,
        remarks: account.remarks,
        status: account.status,
        createdAt: account.createdAt?.toISOString() || new Date().toISOString(),
        updatedAt: account.updatedAt?.toISOString() || new Date().toISOString()
      }));

      console.log(`Returning ${mappedAccounts.length} mapped IAM accounts to frontend`);
      console.log('Sample account:', mappedAccounts[0] || 'No accounts');

      // Ensure we return a proper JSON response
      return res.status(200).json(mappedAccounts);
    } catch (err) {
      console.error("Error fetching IAM accounts:", err);
      return res.status(500).json({
        message: "Failed to fetch IAM accounts",
        error: err.message,
        data: []
      });
    }
  });

  app.post("/api/iam-accounts", async (req: Request, res: Response) => {
    try {
      const accountData = req.body;
      console.log('Creating IAM account with data:', accountData);

      // Validate required fields
      if (!accountData.requestor || !accountData.knoxId || !accountData.permission || !accountData.cloudPlatform) {
        return res.status(400).json({ message: "Requestor, Knox ID, Permission, and Cloud Platform are required for IAM accounts" });
      }

      const newAccount = await storage.createIamAccount(accountData);

      // Log activity
      await storage.createActivity({
        action: "create",
        itemType: "iam-account",
        itemId: newAccount.id,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `IAM account for "${newAccount.requestor}" created with Knox ID "${newAccount.knoxId}"`,
      });

      console.log('IAM account created successfully:', newAccount);
      return res.status(201).json(newAccount);
    } catch (err) {
      console.error("Error creating IAM account:", err);
      return handleError(err, res);
    }
  });

  app.put("/api/iam-accounts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const accountData = req.body;

      console.log(`Updating IAM account with ID: ${id} and data:`, accountData);

      const updatedAccount = await storage.updateIamAccount(id, accountData);

      if (!updatedAccount) {
        return res.status(404).json({ message: "IAM account not found" });
      }

      // Log activity
      await storage.createActivity({
        action: "update",
        itemType: "iam-account",
        itemId: id,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `IAM account for "${updatedAccount.requestor}" updated (Knox ID: "${updatedAccount.knoxId}")`,
      });

      console.log('IAM account updated successfully:', updatedAccount);
      return res.json(updatedAccount);
    } catch (err) {
      console.error("Error updating IAM account:", err);
      return handleError(err, res);
    }
  });

  app.delete("/api/iam-accounts/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      console.log(`DELETE request received for IAM account ID: ${id}`);

      if (!db) {
        console.error("Database not available for deletion");
        return res.status(503).json({
          message: "Database not available"
        });
      }

      const existingAccount = await storage.getIamAccount(id);
      if (!existingAccount) {
        console.log(`IAM account with ID ${id} not found`);
        return res.status(404).json({ message: "IAM account not found" });
      }

      await storage.deleteIamAccount(id);

      // Log activity
      await storage.createActivity({
        action: "delete",
        itemType: "iam-account",
        itemId: id,
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `IAM account for "${existingAccount.requestor}" deleted (Knox ID: "${existingAccount.knoxId}")`,
      });

      console.log(`IAM account with ID ${id} successfully deleted`);
      return res.status(204).send();
    } catch (err) {
      console.error("Error deleting IAM account:", err);
      return res.status(500).json({
        message: "Failed to delete IAM account",
        error: err.message
      });
    }
  });

  app.post("/api/iam-accounts/import", async (req: Request, res: Response) => {
    try {
      const { accounts } = req.body;

      if (!Array.isArray(accounts)) {
        return res.status(400).json({
          message: "Invalid request format. Expected an array of accounts.",
          total: 0,
          successful: 0,
          failed: 0,
          errors: ["Request body must contain an 'accounts' array"]
        });
      }

      if (accounts.length === 0) {
        return res.status(400).json({
          message: "No accounts to import",
          total: 0,
          successful: 0,
          failed: 0,
          errors: ["No accounts provided in the request"]
        });
      }

      console.log(`Starting import of ${accounts.length} IAM accounts...`);

      const results = await storage.importIamAccounts(accounts);

      // Log activity
      await storage.createActivity({
        action: "import",
        itemType: "iam-accounts",
        itemId: 0, // Generic ID for bulk import
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `Imported ${results.successful} IAM accounts, ${results.failed} failed.`,
      });

      console.log(`IAM account import completed. Successful: ${results.successful}, Failed: ${results.failed}`);
      return res.status(results.failed > 0 ? 200 : 201).json(results);
    } catch (err) {
      console.error("Error importing IAM accounts:", err);
      return res.status(500).json({
        message: "Failed to import IAM accounts",
        error: err.message
      });
    }
  });


  // Helper function to format bytes
  function formatBytes(bytes: number, decimals = 2) {
    if (bytes === 0) return '0 Bytes';

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  // Helper function to convert Zabbix severity to text
  function getSeverityFromPriority(priority: string | number | undefined): string {
    const severityMap: { [key: string]: string } = {
      '0': 'not_classified',
      '1': 'information',
      '2': 'warning',
      '3': 'average',
      '4': 'high',
      '5': 'disaster'
    };

    if (priority === undefined || priority === null) {
      return 'not_classified';
    }

    return severityMap[priority.toString()] || 'not_classified';
  }

  // Helper function to convert Zabbix availability status
  function getAvailabilityStatus(available: string | number | undefined): string {
    const statusMap: { [key: string]: string } = {
      '0': 'unknown',
      '1': 'available',
      '2': 'unavailable'
    };

    if (available === undefined || available === null) {
      return 'unknown';
    }

    return statusMap[available.toString()] || 'unknown';
  }

  // Database Management API endpoints
  app.get('/api/admin/database/status', requireAuth, async (req: Request, res: Response) => {
    try {
      if (!db) {
        return res.json({
          connected: false,
          size: "Connection Required",
          tables: 0,
          lastBackup: null,
          backupCount: 0,
          errorMessage: 'Database connection not available'
        });
      }

      // Test database connection and get basic info
      const connectionTest = await db.execute(sql`SELECT version() as version, current_database() as name`);
      const sizeQuery = await db.execute(sql`
        SELECT pg_size_pretty(pg_database_size(current_database())) as size,
               pg_database_size(current_database()) as size_bytes
      `);

      // Get table count
      const tablesQuery = await db.execute(sql`
        SELECT COUNT(*) as table_count
        FROM pg_tables 
        WHERE schemaname = 'public'
      `);

      // Check for recent backups
      let lastBackup = null;
      let backupCount = 0;
      try {
        const fs = await import('fs');
        const path = await import('path');
        const backupDir = path.join(process.cwd(), 'backups');
        if (fs.existsSync(backupDir)) {
          const files = fs.readdirSync(backupDir);
          const sqlFiles = files.filter(f => f.endsWith('.sql')).sort().reverse();
          backupCount = sqlFiles.length;
          if (sqlFiles.length > 0) {
            const stats = fs.statSync(path.join(backupDir, sqlFiles[0]));
            lastBackup = stats.mtime.toISOString();
          }
        }
      } catch (backupError) {
        console.warn('Could not check backup directory:', backupError);
      }

      return res.json({
        connected: true,
        size: sizeQuery.rows[0]?.size || "Unknown",
        tables: parseInt(tablesQuery.rows[0]?.table_count) || 0,
        lastBackup,
        backupCount
      });
    } catch (error) {
      console.error('Database status error:', error);
      return res.json({
        connected: false,
        size: "Error",
        tables: 0,
        lastBackup: null,
        backupCount: 0,
        errorMessage: error.message || 'Failed to connect to database'
      });
    }
  });

  app.get('/api/admin/database/tables', requireAuth, async (req: Request, res: Response) => {
    try {
      if (!db) {
        return res.status(503).json({ message: "Database not available" });
      }

      const tablesResult = await db.execute(`
        SELECT 
          table_name,
          (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = t.table_name AND table_schema = 'public') as column_count,
          pg_size_pretty(pg_total_relation_size(quote_ident(table_name)::regclass)) as size
        FROM information_schema.tables t
        WHERE table_schema = 'public'
        ORDER BY table_name
      `);

      return res.json(tablesResult || []);
    } catch (error) {
      console.error('Error fetching database tables:', error);
      return res.status(500).json({ message: 'Failed to fetch database tables' });
    }
  });

  // Maintenance Settings endpoints
  app.get('/api/admin/database/maintenance', requireAuth, async (req: Request, res: Response) => {
    try {
      // Get maintenance settings from storage
      const settings = await storage.getMaintenanceSettings();

      return res.json(settings || {
        enabled: false,
        schedule: 'daily',
        time: '02:00',
        tasks: ['backup', 'optimize', 'cleanup']
      });
    } catch (error) {
      console.error('Error fetching maintenance settings:', error);
      return res.status(500).json({ message: 'Failed to fetch maintenance settings' });
    }
  });

  app.put('/api/admin/database/maintenance', requireAuth, async (req: Request, res: Response) => {
    try {
      const settings = req.body;
      console.log('Received maintenance settings update:', settings);

      // Save maintenance settings to storage
      await storage.saveMaintenanceSettings(settings);

      // If enabled, set up the scheduled backup
      if (settings.enabled && settings.tasks && settings.tasks.includes('backup')) {
        console.log('Setting up scheduled backup job:', settings.schedule, settings.time);
        scheduleBackupJob(settings.schedule, settings.time);
      } else {
        console.log('Cancelling scheduled backup job');
        cancelScheduledBackup();
      }

      console.log('Maintenance settings saved successfully');
      return res.json(settings);
    } catch (error) {
      console.error('Error saving maintenance settings:', error);
      return res.status(500).json({ message: 'Failed to save maintenance settings' });
    }
  });

  app.post('/api/database/backup', requireAuth, async (req: Request, res: Response) => {
    try {
      if (!process.env.DATABASE_URL) {
        return res.status(500).json({ message: 'Database URL not configured' });
      }

      const { description } = req.body;
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `backup-${timestamp}.sql`;
      const backupDir = path.join(process.cwd(), 'backups');
      const filePath = path.join(backupDir, filename);

      // Ensure backup directory exists
      if (!fs.existsSync(backupDir)) {
        fs.mkdirSync(backupDir, { recursive: true });
      }

      // Extract database connection details
      const dbUrl = new URL(process.env.DATABASE_URL);
      const dbName = dbUrl.pathname.slice(1);
      const host = dbUrl.hostname;
      const port = dbUrl.port || '5432';
      const username = dbUrl.username;
      const password = dbUrl.password;

      // Create pg_dump command
      const dumpCommand = `pg_dump --host=${host} --port=${port} --username=${username} --dbname=${dbName} --no-password --verbose --clean --no-owner --no-privileges`;

      return new Promise((resolve, reject) => {
        const dumpProcess = spawn('pg_dump', [
          `--host=${host}`,
          `--port=${port}`,
          `--username=${username}`,
          `--dbname=${dbName}`,
          '--no-password',
          '--verbose',
          '--clean',
          '--no-owner',
          '--no-privileges'
        ], {
          env: { ...process.env, PGPASSWORD: password },
          stdio: ['ignore', 'pipe', 'pipe']
        });

        const writeStream = fs.createWriteStream(filePath);

        dumpProcess.stdout.pipe(writeStream);

        let errorOutput = '';
        dumpProcess.stderr.on('data', (data) => {
          errorOutput += data.toString();
        });

        dumpProcess.on('close', (code) => {
          if (code === 0) {
            // Add metadata to backup file
            const metadata = `-- PostgreSQL database dump\n-- Dumped on: ${new Date().toISOString()}\n-- Description: ${description || 'No description'}\n-- Database: ${dbName}\n\n`;
            const originalContent = fs.readFileSync(filePath, 'utf8');
            fs.writeFileSync(filePath, metadata + originalContent);

            const stats = fs.statSync(filePath);
            resolve(res.json({
              success: true,
              filename,
              size: stats.size,
              path: filePath,
              created: new Date().toISOString()
            }));
          } else {
            reject(res.status(500).json({ 
              message: 'Backup failed', 
              error: errorOutput || `pg_dump exited with code ${code}` 
            }));
          }
        });

        dumpProcess.on('error', (error) => {
          reject(res.status(500).json({ 
            message: 'Failed to start backup process', 
            error: error.message 
          }));
        });
      });

    } catch (error) {
      console.error('Backup error:', error);
      return res.status(500).json({ message: 'Backup failed', error: error.message });
    }
  });

  app.get('/api/database/backups', requireAuth, async (req: Request, res: Response) => {
    try {
      const backupDir = path.join(process.cwd(), 'backups');

      if (!fs.existsSync(backupDir)) {
        return res.json([]);
      }

      const backupFiles = fs.readdirSync(backupDir)
        .filter(file => file.endsWith('.sql'))
        .map(filename => {
          const filePath = path.join(backupDir, filename);
          const stats = fs.statSync(filePath);

          // Try to extract description from file
          let description = 'No description';
          try {
            const content = fs.readFileSync(filePath, 'utf8');
            const descMatch = content.match(/-- Description: (.+)/);
            if (descMatch) {
              description = descMatch[1];
            }
          } catch (e) {
            // Ignore read errors
          }

          return {
            id: filename.replace('.sql', ''),
            filename,
            description,
            size: `${Math.round(stats.size / 1024)} KB`,
            created: stats.mtime.toISOString(),
            path: filePath
          };
        })
        .sort((a, b) => new Date(b.created).getTime() - new Date(a.created).getTime());

      return res.json(backupFiles);
    } catch (error) {
      console.error('Error fetching backups:', error);
      return res.status(500).json({ message: 'Failed to fetch backups' });
    }
  });

  app.get('/api/database/backups/:filename/download', requireAuth, async (req: Request, res: Response) => {
    try {
      const { filename } = req.params;
      const backupDir = path.join(process.cwd(), 'backups');
      const filePath = path.join(backupDir, filename);

      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: 'Backup file not found' });
      }

      res.setHeader('Content-Type', 'application/sql');
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);

      const fileStream = fs.createReadStream(filePath);
      fileStream.pipe(res);

    } catch (error) {
      console.error('Download error:', error);
      return res.status(500).json({ message: 'Failed to download backup' });
    }
  });

  app.post('/api/database/restore', requireAuth, async (req: Request, res: Response) => {
    try {
      if (!db) {
        return res.status(503).json({ message: "Database connection required" });
      }

      const { backupPath } = req.body;

      if (!backupPath) {
        return res.status(400).json({ message: "Backup path is required" });
      }

      const fs = require('fs');
      const { exec } = require('child_process');
      const { promisify } = require('util');
      const execAsync = promisify(exec);

      if (!fs.existsSync(backupPath)) {
        return res.status(404).json({ message: "Backup file not found" });
      }

      try {
        const databaseUrl = process.env.DATABASE_URL;
        if (databaseUrl) {
          // Construct the psql restore command
          // Using '--single-transaction' for atomic restore is generally good practice
          // '--clean' drops database objects before recreating them
          const restoreCmd = `psql "${databaseUrl}" --clean --single-transaction < "${backupPath}"`;
          console.log(`Executing restore command: ${restoreCmd}`);

          // Execute the command
          await execAsync(restoreCmd);

          // Log the restore activity
          await storage.createActivity({
            action: "restore",
            itemType: "database",
            itemId: 1, // Assuming a generic ID for database actions
            userId: req.user?.id || 1,
            timestamp: new Date().toISOString(),
            notes: `Database restored from backup: ${backupPath}`,
          });

          return res.json({ 
            success: true, 
            message: "Database restored successfully" 
          });
        } else {
          throw new Error('No DATABASE_URL available for restore');
        }
      } catch (restoreError) {
        console.error('Restore error:', restoreError);
        return res.status(500).json({ 
          message: "Failed to restore database", 
          error: restoreError.message 
        });
      }
    } catch (error) {
      console.error("Restore error:", error);
      return res.status(500).json({ 
        message: "Database restore failed", 
        error: error.message 
      });
    }
  });

  // Maintenance endpoints
  app.put("/api/admin/database/maintenance", requireAuth, async (req: Request, res: Response) => {
    try {
      const settings = req.body;

      // In a real implementation, you would save these settings to the database
      // For now, just return success
      console.log('Received maintenance settings:', settings);

      // If backup is enabled, schedule it
      if (settings.enabled && settings.tasks && settings.tasks.includes('backup')) {
        console.log(`Scheduling backup for ${settings.schedule} at ${settings.time}`);
        scheduleBackupJob(settings.schedule, settings.time); // Assuming this function exists and handles scheduling
      } else {
        console.log('Cancelling scheduled backup');
        cancelScheduledBackup(); // Assuming this function exists and handles cancelling
      }

      // Log the update
      await storage.createActivity({
        action: "update",
        itemType: "settings",
        itemId: 1, // Assuming a generic ID for settings
        userId: req.user?.id || 1,
        timestamp: new Date().toISOString(),
        notes: `Database maintenance settings updated: Backup ${settings.enabled ? 'enabled' : 'disabled'}, Schedule: ${settings.schedule}, Time: ${settings.time}`,
      });

      return res.json({ 
        success: true, 
        message: "Maintenance settings updated successfully",
        settings 
      });
    } catch (error) {
      console.error("Maintenance settings error:", error);
      return res.status(500).json({ 
        message: "Failed to update maintenance settings", 
        error: error.message 
      });
    }
  });

  // Initialize scheduled backup on server start
  setTimeout(async () => {
    try {
      const maintenanceSettings = await storage.getMaintenanceSettings();
      if (maintenanceSettings?.enabled && maintenanceSettings?.tasks?.includes('backup')) {
        console.log('Initializing scheduled backup from saved settings...');
        scheduleBackupJob(maintenanceSettings.schedule, maintenanceSettings.time);
      }
    } catch (error) {
      console.error('Failed to initialize scheduled backup:', error);
    }
  }, 1000);

  // User logs endpoint
  app.get('/api/logs/users/:userId', requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const { date } = req.query;

      if (!userId) {
        return res.status(400).json({ message: 'User ID is required' });
      }

      // Get user information
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }

      // Get user activities from the database
      const userActivities = await storage.getActivitiesByUser(userId);

      // Filter by date if provided
      let filteredActivities = userActivities;
      if (date) {
        const targetDate = new Date(date as string);
        const nextDay = new Date(targetDate);
        nextDay.setDate(nextDay.getDate() + 1);

        filteredActivities = userActivities.filter(activity => {
          const activityDate = new Date(activity.timestamp);
          return activityDate >= targetDate && activityDate < nextDay;
        });
      }

      // Format as log entries
      const logEntries = filteredActivities.map(activity => {
        const timestamp = new Date(activity.timestamp).toISOString();
        const action = activity.action.toUpperCase();
        const itemType = activity.itemType.toUpperCase();
        return `[${timestamp}] [INFO] [USER-${userId}] ${action} ${itemType} ${activity.itemId} - ${activity.notes || 'No notes'}`;
      });

      const logContent = logEntries.join('\n');

      return res.json({
        category: 'user-activity',
        date: date || new Date().toISOString().split('T')[0],
        content: logContent,
        lines: logEntries.length,
        user: {
          id: user.id,
          username: user.username,
          firstName: user.firstName,
          lastName: user.lastName
        }
      });

    } catch (error) {
      console.error('Error fetching user logs:', error);
      return res.status(500).json({ message: 'Failed to fetch user logs' });
    }
  });

  // Get all users for user logs dropdown
  app.get('/api/logs/users', requireAuth, async (req: Request, res: Response) => {
    try {
      const users = await storage.getUsers();
      const userList = users.map(user => ({
        id: user.id,
        username: user.username,
        firstName: user.firstName,
        lastName: user.lastName,
        fullName: `${user.firstName} ${user.lastName} (${user.username})`
      }));

      return res.json(userList);
    } catch (error) {
      console.error('Error fetching users list:', error);
      return res.status(500).json({ message: 'Failed to fetch users list' });
    }
  });


  // Create HTTP server
  const httpServer = createServer(app);
  return httpServer;
}