
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils";
import { UserIcon, CalendarIcon, PackageIcon } from "lucide-react";

interface ConsumableAssignmentsProps {
  consumableId: number;
}

export default function ConsumableAssignments({ consumableId }: ConsumableAssignmentsProps) {
  const { data: assignments = [], isLoading } = useQuery({
    queryKey: [`/api/consumables/${consumableId}/assignments`],
    queryFn: async () => {
      const response = await fetch(`/api/consumables/${consumableId}/assignments`);
      if (!response.ok) {
        throw new Error('Failed to fetch assignments');
      }
      return response.json();
    },
  });

  if (isLoading) {
    return (
      <div className="mt-4">
        <div className="animate-pulse bg-slate-200 h-20 rounded-lg"></div>
      </div>
    );
  }

  if (assignments.length === 0) {
    return null;
  }

  return (
    <Card className="mt-4">
      <CardHeader className="pb-3">
        <CardTitle className="text-sm font-semibold text-slate-700 flex items-center gap-2">
          <UserIcon className="h-4 w-4" />
          Current Assignments ({assignments.length})
        </CardTitle>
      </CardHeader>
      <CardContent className="pt-0">
        <div className="space-y-2">
          {assignments.map((assignment: any) => (
            <div key={assignment.id} className="flex items-center justify-between p-2 bg-slate-50 rounded-lg border border-slate-200">
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1 text-sm">
                  <UserIcon className="h-3 w-3 text-slate-500" />
                  <span className="font-medium">{assignment.assignedTo}</span>
                </div>
                <div className="flex items-center gap-1 text-xs text-slate-500">
                  <PackageIcon className="h-3 w-3" />
                  <span>Qty: {assignment.quantity}</span>
                </div>
                {assignment.knoxId && (
                  <Badge variant="outline" className="text-xs">
                    Knox: {assignment.knoxId}
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-1 text-xs text-slate-500">
                <CalendarIcon className="h-3 w-3" />
                <span>{formatDate(assignment.assignedDate)}</span>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
