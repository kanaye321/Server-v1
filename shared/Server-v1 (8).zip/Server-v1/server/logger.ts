
import * as fs from 'fs';
import * as path from 'path';

interface LogEntry {
  timestamp: string;
  level: 'INFO' | 'WARN' | 'ERROR' | 'DEBUG' | 'SYSTEM';
  category: string;
  message: string;
  userId?: number;
  username?: string;
  ipAddress?: string;
  userAgent?: string;
  details?: any;
}

class ExternalLogger {
  private logsDir: string;

  constructor() {
    this.logsDir = path.join(process.cwd(), 'logs');
    this.ensureLogDirectory();
  }

  private ensureLogDirectory() {
    if (!fs.existsSync(this.logsDir)) {
      fs.mkdirSync(this.logsDir, { recursive: true });
    }
  }

  private formatLogEntry(entry: LogEntry): string {
    const { timestamp, level, category, message, userId, username, ipAddress, userAgent, details } = entry;
    
    let logLine = `[${timestamp}] [${level}] [${category.toUpperCase()}] ${message}`;
    
    if (username) {
      logLine += ` | User: ${username}`;
    }
    
    if (userId) {
      logLine += ` (ID: ${userId})`;
    }
    
    if (ipAddress) {
      logLine += ` | IP: ${ipAddress}`;
    }
    
    if (userAgent) {
      logLine += ` | Agent: ${userAgent.substring(0, 100)}`;
    }
    
    if (details) {
      logLine += ` | Details: ${JSON.stringify(details)}`;
    }
    
    return logLine + '\n';
  }

  private getLogFileName(category: string): string {
    const date = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
    return `${category.toLowerCase()}-${date}.log`;
  }

  private writeToFile(category: string, logEntry: string) {
    try {
      const fileName = this.getLogFileName(category);
      const filePath = path.join(this.logsDir, fileName);
      
      fs.appendFileSync(filePath, logEntry, 'utf8');
    } catch (error) {
      console.error('Failed to write to log file:', error);
    }
  }

  private createLogEntry(
    level: LogEntry['level'],
    category: string,
    message: string,
    metadata?: Partial<LogEntry>
  ): LogEntry {
    return {
      timestamp: new Date().toISOString(),
      level,
      category,
      message,
      ...metadata
    };
  }

  // User Authentication Logs
  logUserAuth(action: string, username: string, success: boolean, ipAddress?: string, userAgent?: string) {
    const entry = this.createLogEntry(
      success ? 'INFO' : 'WARN',
      'auth',
      `User ${action}: ${username} - ${success ? 'SUCCESS' : 'FAILED'}`,
      { username, ipAddress, userAgent }
    );
    
    this.writeToFile('auth', this.formatLogEntry(entry));
    this.writeToFile('system', this.formatLogEntry(entry)); // Also log to system
  }

  // Database Operations
  logDatabase(operation: string, table: string, details?: any, userId?: number, username?: string) {
    const entry = this.createLogEntry(
      'INFO',
      'database',
      `Database ${operation} on table '${table}'`,
      { details, userId, username }
    );
    
    this.writeToFile('database', this.formatLogEntry(entry));
    this.writeToFile('system', this.formatLogEntry(entry));
  }

  // Asset Operations
  logAssetOperation(action: string, assetInfo: any, userId?: number, username?: string) {
    const entry = this.createLogEntry(
      'INFO',
      'assets',
      `Asset ${action}: ${assetInfo.name || assetInfo.assetTag || 'Unknown'}`,
      { details: assetInfo, userId, username }
    );
    
    this.writeToFile('assets', this.formatLogEntry(entry));
    this.writeToFile('system', this.formatLogEntry(entry));
  }

  // User Management
  logUserManagement(action: string, targetUser: string, details?: any, adminId?: number, adminUsername?: string) {
    const entry = this.createLogEntry(
      'INFO',
      'user-management',
      `User management ${action}: ${targetUser}`,
      { details, userId: adminId, username: adminUsername }
    );
    
    this.writeToFile('user-management', this.formatLogEntry(entry));
    this.writeToFile('system', this.formatLogEntry(entry));
  }

  // Security Events
  logSecurity(event: string, details: any, userId?: number, username?: string, ipAddress?: string) {
    const entry = this.createLogEntry(
      'WARN',
      'security',
      `Security event: ${event}`,
      { details, userId, username, ipAddress }
    );
    
    this.writeToFile('security', this.formatLogEntry(entry));
    this.writeToFile('system', this.formatLogEntry(entry));
  }

  // System Operations
  logSystem(event: string, details?: any, userId?: number, username?: string) {
    const entry = this.createLogEntry(
      'SYSTEM',
      'system',
      `System event: ${event}`,
      { details, userId, username }
    );
    
    this.writeToFile('system', this.formatLogEntry(entry));
  }

  // Backup Operations
  logBackup(operation: string, details?: any, userId?: number, username?: string) {
    const entry = this.createLogEntry(
      'INFO',
      'backup',
      `Backup ${operation}`,
      { details, userId, username }
    );
    
    this.writeToFile('backup', this.formatLogEntry(entry));
    this.writeToFile('system', this.formatLogEntry(entry));
  }

  // API Requests
  logApiRequest(method: string, endpoint: string, statusCode: number, duration?: number, responseData?: any, userId?: number, username?: string, ipAddress?: string, userAgent?: string) {
    const entry = this.createLogEntry(
      statusCode >= 400 ? 'ERROR' : 'INFO',
      'api',
      `${method} ${endpoint} - ${statusCode}${duration ? ` (${duration}ms)` : ''}`,
      { userId, username, ipAddress, userAgent, details: { method, endpoint, statusCode, duration, responseData } }
    );
    
    this.writeToFile('api', this.formatLogEntry(entry));
    
    // Log errors to system log as well
    if (statusCode >= 400) {
      this.writeToFile('system', this.formatLogEntry(entry));
    }
  }

  // Error Logging
  logError(error: Error, context: string, userId?: number, username?: string) {
    const entry = this.createLogEntry(
      'ERROR',
      'errors',
      `Error in ${context}: ${error.message}`,
      { 
        details: { 
          stack: error.stack, 
          name: error.name,
          context 
        }, 
        userId, 
        username 
      }
    );
    
    this.writeToFile('errors', this.formatLogEntry(entry));
    this.writeToFile('system', this.formatLogEntry(entry));
  }

  // JIRA Integration
  logJiraIntegration(action: string, details?: any, userId?: number, username?: string) {
    const entry = this.createLogEntry(
      'INFO',
      'jira',
      `JIRA ${action}`,
      { details, userId, username }
    );
    
    this.writeToFile('jira', this.formatLogEntry(entry));
    this.writeToFile('system', this.formatLogEntry(entry));
  }

  // Network Discovery
  logNetworkDiscovery(action: string, details?: any, userId?: number, username?: string) {
    const entry = this.createLogEntry(
      'INFO',
      'network',
      `Network discovery ${action}`,
      { details, userId, username }
    );
    
    this.writeToFile('network', this.formatLogEntry(entry));
    this.writeToFile('system', this.formatLogEntry(entry));
  }

  // Performance Monitoring
  logPerformance(metric: string, value: any, details?: any) {
    const entry = this.createLogEntry(
      'INFO',
      'performance',
      `Performance metric: ${metric} = ${value}`,
      { details: { metric, value, ...details } }
    );
    
    this.writeToFile('performance', this.formatLogEntry(entry));
  }

  // Custom log method for any category
  log(level: LogEntry['level'], category: string, message: string, metadata?: Partial<LogEntry>) {
    const entry = this.createLogEntry(level, category, message, metadata);
    this.writeToFile(category, this.formatLogEntry(entry));
    
    // Always log WARN, ERROR, and SYSTEM level messages to system log
    if (['WARN', 'ERROR', 'SYSTEM'].includes(level)) {
      this.writeToFile('system', this.formatLogEntry(entry));
    }
  }

  // Get log file contents
  getLogFile(category: string, date?: string): string | null {
    try {
      const fileName = date ? `${category.toLowerCase()}-${date}.log` : this.getLogFileName(category);
      const filePath = path.join(this.logsDir, fileName);
      
      if (fs.existsSync(filePath)) {
        return fs.readFileSync(filePath, 'utf8');
      }
      
      return null;
    } catch (error) {
      console.error('Failed to read log file:', error);
      return null;
    }
  }

  // List available log files
  getAvailableLogFiles(): string[] {
    try {
      return fs.readdirSync(this.logsDir).filter(file => file.endsWith('.log'));
    } catch (error) {
      console.error('Failed to list log files:', error);
      return [];
    }
  }

  // Clean old log files (older than specified days)
  cleanOldLogs(daysToKeep: number = 30) {
    try {
      const files = fs.readdirSync(this.logsDir);
      const cutoffDate = new Date();
      cutoffDate.setDate(cutoffDate.getDate() - daysToKeep);

      files.forEach(file => {
        const filePath = path.join(this.logsDir, file);
        const stats = fs.statSync(filePath);
        
        if (stats.mtime < cutoffDate) {
          fs.unlinkSync(filePath);
          this.logSystem('log_cleanup', { deletedFile: file, age: stats.mtime });
        }
      });
    } catch (error) {
      console.error('Failed to clean old logs:', error);
      this.logError(error, 'log_cleanup');
    }
  }

  // Server heartbeat logging (for monitoring server availability)
  logHeartbeat(serverStats?: any) {
    const entry = this.createLogEntry(
      'INFO',
      'heartbeat',
      'Server heartbeat - System operational',
      { 
        details: { 
          timestamp: new Date().toISOString(),
          uptime: process.uptime(),
          memory: process.memoryUsage(),
          ...serverStats
        } 
      }
    );
    
    this.writeToFile('heartbeat', this.formatLogEntry(entry));
  }

  // Application lifecycle events
  logLifecycle(event: string, details?: any) {
    const entry = this.createLogEntry(
      'SYSTEM',
      'lifecycle',
      `Application ${event}`,
      { details }
    );
    
    this.writeToFile('lifecycle', this.formatLogEntry(entry));
    this.writeToFile('system', this.formatLogEntry(entry));
  }

  // Critical error logging (always writes to multiple files for redundancy)
  logCritical(message: string, error?: Error, context?: string) {
    const entry = this.createLogEntry(
      'ERROR',
      'critical',
      message,
      { 
        details: { 
          error: error?.message,
          stack: error?.stack,
          context,
          timestamp: new Date().toISOString()
        } 
      }
    );
    
    const logLine = this.formatLogEntry(entry);
    
    // Write to multiple files for redundancy
    this.writeToFile('critical', logLine);
    this.writeToFile('errors', logLine);
    this.writeToFile('system', logLine);
    
    // Also write to a daily critical log
    const criticalFileName = `critical-${new Date().toISOString().split('T')[0]}.log`;
    const criticalPath = path.join(this.logsDir, criticalFileName);
    try {
      fs.appendFileSync(criticalPath, logLine, 'utf8');
    } catch (writeError) {
      console.error('Failed to write critical log:', writeError);
    }
  }
}

// Create singleton instance
export const externalLogger = new ExternalLogger();
