
import { CronJob } from 'cron';
import { spawn } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

let scheduledBackupJob: CronJob | null = null;

export interface BackupSchedule {
  schedule: string;
  time: string;
}

export function scheduleBackupJob(schedule: string, time: string): void {
  // Cancel existing job if it exists
  cancelScheduledBackup();

  try {
    // Convert schedule and time to cron format
    const cronPattern = convertToCronPattern(schedule, time);
    
    console.log(`Scheduling backup job with pattern: ${cronPattern}`);
    
    scheduledBackupJob = new CronJob(
      cronPattern,
      async () => {
        console.log('Running scheduled backup...');
        try {
          await performAutomaticBackup();
          console.log('Scheduled backup completed successfully');
        } catch (error) {
          console.error('Scheduled backup failed:', error);
        }
      },
      null,
      true,
      'America/New_York' // Default timezone, adjust as needed
    );

    console.log('Backup job scheduled successfully');
  } catch (error) {
    console.error('Failed to schedule backup job:', error);
  }
}

export function cancelScheduledBackup(): void {
  if (scheduledBackupJob) {
    scheduledBackupJob.stop();
    scheduledBackupJob = null;
    console.log('Scheduled backup job cancelled');
  }
}

function convertToCronPattern(schedule: string, time: string): string {
  // Parse time (e.g., "02:00" or "14:30")
  const [hours, minutes] = time.split(':').map(num => parseInt(num, 10));
  
  switch (schedule.toLowerCase()) {
    case 'daily':
      return `${minutes} ${hours} * * *`;
    case 'weekly':
      return `${minutes} ${hours} * * 0`; // Sunday
    case 'monthly':
      return `${minutes} ${hours} 1 * *`; // First day of month
    default:
      throw new Error(`Unsupported schedule: ${schedule}`);
  }
}

async function performAutomaticBackup(): Promise<void> {
  if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL not configured for backup');
  }

  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `scheduled-backup-${timestamp}.sql`;
  const backupDir = path.join(process.cwd(), 'backups');
  const filePath = path.join(backupDir, filename);

  // Ensure backup directory exists
  if (!fs.existsSync(backupDir)) {
    fs.mkdirSync(backupDir, { recursive: true });
  }

  // Extract database connection details
  const dbUrl = new URL(process.env.DATABASE_URL);
  const dbName = dbUrl.pathname.slice(1);
  const host = dbUrl.hostname;
  const port = dbUrl.port || '5432';
  const username = dbUrl.username;
  const password = dbUrl.password;

  return new Promise((resolve, reject) => {
    const dumpProcess = spawn('pg_dump', [
      `--host=${host}`,
      `--port=${port}`,
      `--username=${username}`,
      `--dbname=${dbName}`,
      '--no-password',
      '--verbose',
      '--clean',
      '--no-owner',
      '--no-privileges',
      '--file',
      filePath
    ], {
      env: { ...process.env, PGPASSWORD: password },
      stdio: ['ignore', 'pipe', 'pipe']
    });

    let errorOutput = '';
    dumpProcess.stderr.on('data', (data) => {
      errorOutput += data.toString();
    });

    dumpProcess.on('close', (code) => {
      if (code === 0) {
        console.log(`Automatic backup created: ${filename}`);
        resolve();
      } else {
        reject(new Error(`Backup failed with code ${code}: ${errorOutput}`));
      }
    });

    dumpProcess.on('error', (error) => {
      reject(new Error(`Backup process failed to start: ${error.message}`));
    });
  });
}

export function getBackupStatus(): { isScheduled: boolean; nextRun: string | null } {
  if (scheduledBackupJob && scheduledBackupJob.running) {
    return {
      isScheduled: true,
      nextRun: scheduledBackupJob.nextDate()?.toISOString() || null
    };
  }
  
  return {
    isScheduled: false,
    nextRun: null
  };
}
