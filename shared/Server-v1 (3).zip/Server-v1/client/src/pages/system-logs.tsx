
import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";
import {
  FileTextIcon,
  DownloadIcon,
  RefreshCwIcon,
  SearchIcon,
  TrashIcon,
  AlertCircleIcon,
  InfoIcon,
  ShieldIcon,
  DatabaseIcon,
  UserIcon,
  ServerIcon,
  ActivityIcon,
  ClockIcon,
} from "lucide-react";

interface LogFile {
  category: string;
  date: string;
  content: string;
  lines: number;
}

interface LogCategories {
  categories: string[];
  files: string[];
}

export default function SystemLogs() {
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<string>("");
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [searchTerm, setSearchTerm] = useState("");
  const [logContent, setLogContent] = useState<string>("");
  const [filteredContent, setFilteredContent] = useState<string>("");
  const [activeTab, setActiveTab] = useState("viewer");

  // Fetch available log categories
  const { data: logCategories, isLoading: categoriesLoading } = useQuery({
    queryKey: ['/api/logs/categories'],
    queryFn: async (): Promise<LogCategories> => {
      const response = await fetch('/api/logs/categories', {
        credentials: 'include'
      });
      if (!response.ok) {
        throw new Error('Failed to fetch log categories');
      }
      return response.json();
    },
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Fetch log file content
  const { data: logFile, isLoading: logLoading, error: logError } = useQuery({
    queryKey: ['/api/logs', selectedCategory, selectedDate],
    queryFn: async (): Promise<LogFile | null> => {
      if (!selectedCategory) return null;
      
      const response = await fetch(`/api/logs/${selectedCategory}?date=${selectedDate}`, {
        credentials: 'include'
      });
      
      if (response.status === 404) {
        return null; // No log file for this date
      }
      
      if (!response.ok) {
        throw new Error('Failed to fetch log file');
      }
      
      return response.json();
    },
    enabled: !!selectedCategory,
  });

  // Update log content when data changes
  useEffect(() => {
    if (logFile?.content) {
      setLogContent(logFile.content);
    } else {
      setLogContent("");
    }
  }, [logFile]);

  // Filter log content based on search term
  useEffect(() => {
    if (!searchTerm) {
      setFilteredContent(logContent);
    } else {
      const lines = logContent.split('\n');
      const filtered = lines.filter(line => 
        line.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setFilteredContent(filtered.join('\n'));
    }
  }, [logContent, searchTerm]);

  // Log cleanup mutation
  const cleanupMutation = useMutation({
    mutationFn: async (daysToKeep: number) => {
      const response = await fetch('/api/logs/cleanup', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify({ daysToKeep })
      });
      
      if (!response.ok) {
        throw new Error('Failed to cleanup logs');
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Logs cleaned up",
        description: "Old log files have been removed successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/logs/categories'] });
    },
    onError: (error: any) => {
      toast({
        title: "Cleanup failed",
        description: error.message || "Failed to cleanup log files.",
        variant: "destructive",
      });
    }
  });

  const handleDownloadLog = () => {
    if (!selectedCategory) return;
    
    const url = `/api/logs/${selectedCategory}/download?date=${selectedDate}`;
    window.open(url, '_blank');
  };

  const handleRefresh = () => {
    queryClient.invalidateQueries({ queryKey: ['/api/logs', selectedCategory, selectedDate] });
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'auth':
        return <UserIcon className="h-4 w-4" />;
      case 'security':
        return <ShieldIcon className="h-4 w-4" />;
      case 'database':
        return <DatabaseIcon className="h-4 w-4" />;
      case 'api':
        return <ServerIcon className="h-4 w-4" />;
      case 'errors':
        return <AlertCircleIcon className="h-4 w-4" />;
      case 'system':
        return <ActivityIcon className="h-4 w-4" />;
      default:
        return <FileTextIcon className="h-4 w-4" />;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'errors':
        return 'destructive';
      case 'security':
        return 'secondary';
      case 'auth':
        return 'default';
      case 'database':
        return 'outline';
      default:
        return 'outline';
    }
  };

  const getLogLevelBadge = (line: string) => {
    if (line.includes('[ERROR]')) {
      return <Badge variant="destructive" className="text-xs">ERROR</Badge>;
    } else if (line.includes('[WARN]')) {
      return <Badge variant="secondary" className="text-xs">WARN</Badge>;
    } else if (line.includes('[INFO]')) {
      return <Badge variant="default" className="text-xs">INFO</Badge>;
    } else if (line.includes('[DEBUG]')) {
      return <Badge variant="outline" className="text-xs">DEBUG</Badge>;
    } else if (line.includes('[SYSTEM]')) {
      return <Badge variant="default" className="text-xs">SYSTEM</Badge>;
    }
    return null;
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-800">System Logs</h1>
          <p className="text-sm text-gray-600">View and manage detailed system log files</p>
        </div>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            variant="outline"
            onClick={handleRefresh}
            disabled={logLoading}
          >
            <RefreshCwIcon className="h-4 w-4 mr-1" />
            Refresh
          </Button>
          <Button
            size="sm"
            variant="outline"
            onClick={handleDownloadLog}
            disabled={!logFile}
          >
            <DownloadIcon className="h-4 w-4 mr-1" />
            Download
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="viewer">Log Viewer</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="management">Management</TabsTrigger>
        </TabsList>

        <TabsContent value="viewer" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <FileTextIcon className="h-5 w-5" />
                Log File Viewer
              </CardTitle>
              <CardDescription>
                Select a log category and date to view detailed system logs
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm font-medium mb-1 block">Category</label>
                  <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select log category" />
                    </SelectTrigger>
                    <SelectContent>
                      {logCategories?.categories.map((category) => (
                        <SelectItem key={category} value={category}>
                          <div className="flex items-center gap-2">
                            {getCategoryIcon(category)}
                            {category}
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">Date</label>
                  <Input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => setSelectedDate(e.target.value)}
                  />
                </div>
                
                <div>
                  <label className="text-sm font-medium mb-1 block">Search</label>
                  <div className="relative">
                    <SearchIcon className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Search in logs..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
              </div>

              {logFile && (
                <div className="flex items-center gap-4 p-3 bg-gray-50 rounded-md">
                  <Badge variant={getCategoryColor(selectedCategory)}>
                    {selectedCategory}
                  </Badge>
                  <span className="text-sm text-gray-600">
                    {logFile.lines} lines • {formatDate(selectedDate)}
                  </span>
                  {searchTerm && (
                    <span className="text-sm text-blue-600">
                      Filtered results
                    </span>
                  )}
                </div>
              )}

              <div className="border rounded-md">
                {logLoading ? (
                  <div className="flex items-center justify-center h-64">
                    <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                  </div>
                ) : logError ? (
                  <div className="flex items-center justify-center h-64 text-red-500">
                    <AlertCircleIcon className="h-8 w-8 mr-2" />
                    Failed to load log file
                  </div>
                ) : !logFile ? (
                  <div className="flex items-center justify-center h-64 text-gray-500">
                    <FileTextIcon className="h-8 w-8 mr-2" />
                    {selectedCategory ? 'No log file found for this date' : 'Select a category to view logs'}
                  </div>
                ) : (
                  <div className="relative">
                    <Textarea
                      value={filteredContent}
                      readOnly
                      className="min-h-[500px] font-mono text-xs resize-none border-0 focus:ring-0"
                      placeholder="Log content will appear here..."
                    />
                    {filteredContent && (
                      <div className="absolute top-2 right-2">
                        <Badge variant="outline" className="text-xs">
                          {filteredContent.split('\n').length - 1} lines
                        </Badge>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Log Categories</CardTitle>
              <CardDescription>
                Overview of available log categories and their purposes
              </CardDescription>
            </CardHeader>
            <CardContent>
              {categoriesLoading ? (
                <div className="flex items-center justify-center h-32">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {logCategories?.categories.map((category) => (
                    <Card key={category} className="cursor-pointer hover:shadow-md transition-shadow"
                          onClick={() => {
                            setSelectedCategory(category);
                            setActiveTab("viewer");
                          }}>
                      <CardContent className="p-4">
                        <div className="flex items-center gap-3">
                          {getCategoryIcon(category)}
                          <div>
                            <h3 className="font-medium capitalize">{category}</h3>
                            <p className="text-xs text-gray-500">
                              {category === 'auth' && 'User authentication events'}
                              {category === 'security' && 'Security-related events'}
                              {category === 'database' && 'Database operations'}
                              {category === 'api' && 'API request logs'}
                              {category === 'errors' && 'System error logs'}
                              {category === 'system' && 'General system events'}
                              {category === 'assets' && 'Asset management operations'}
                              {category === 'backup' && 'Backup operations'}
                              {category === 'performance' && 'Performance metrics'}
                              {!['auth', 'security', 'database', 'api', 'errors', 'system', 'assets', 'backup', 'performance'].includes(category) && 'Application logs'}
                            </p>
                          </div>
                        </div>
                        <div className="mt-3">
                          <Badge variant={getCategoryColor(category)} className="text-xs">
                            {logCategories.files.filter(f => f.startsWith(category)).length} files
                          </Badge>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="management" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ClockIcon className="h-5 w-5" />
                Log Management
              </CardTitle>
              <CardDescription>
                Manage log files and configure cleanup policies
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="text-lg font-medium mb-4">Available Log Files</h3>
                {logCategories?.files.length ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                    {logCategories.files.map((file) => (
                      <div key={file} className="flex items-center justify-between p-2 border rounded">
                        <span className="text-sm font-mono">{file}</span>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            const [category, dateStr] = file.replace('.log', '').split('-');
                            setSelectedCategory(category);
                            setSelectedDate(dateStr);
                            setActiveTab("viewer");
                          }}
                        >
                          View
                        </Button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-500">No log files found</p>
                )}
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-medium mb-4">Cleanup Old Logs</h3>
                <div className="flex items-center gap-4">
                  <div className="flex-1">
                    <p className="text-sm text-gray-600 mb-2">
                      Remove log files older than the specified number of days
                    </p>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        className="text-red-600 border-red-200 hover:bg-red-50"
                        onClick={() => cleanupMutation.mutate(7)}
                        disabled={cleanupMutation.isPending}
                      >
                        <TrashIcon className="h-4 w-4 mr-1" />
                        Cleanup (7 days)
                      </Button>
                      <Button
                        variant="outline"
                        className="text-red-600 border-red-200 hover:bg-red-50"
                        onClick={() => cleanupMutation.mutate(30)}
                        disabled={cleanupMutation.isPending}
                      >
                        <TrashIcon className="h-4 w-4 mr-1" />
                        Cleanup (30 days)
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
