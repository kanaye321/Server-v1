import { useState, useEffect } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDate } from "@/lib/utils";
import {
  DatabaseIcon,
  DownloadIcon,
  UploadIcon,
  HardDriveIcon,
  CheckCircleIcon,
  AlertCircleIcon,
  RefreshCwIcon,
  ClockIcon,
  SettingsIcon,
  PlayIcon,
  PauseIcon,
  TrashIcon,
  TableIcon,
} from "lucide-react";

interface DatabaseStatus {
  connected: boolean;
  size: string;
  tables: number;
  lastBackup: string | null;
  backupCount: number;
}

interface BackupItem {
  id: string;
  filename: string;
  description: string;
  size: string;
  created: string;
}

interface MaintenanceSettings {
  enabled: boolean;
  schedule: string;
  time: string;
  tasks: string[];
}

export default function Database() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("overview");
  const [isCreateBackupDialogOpen, setIsCreateBackupDialogOpen] = useState(false);
  const [isRestoreDialogOpen, setIsRestoreDialogOpen] = useState(false);
  const [selectedBackup, setSelectedBackup] = useState<BackupItem | null>(null);
  const [backupDescription, setBackupDescription] = useState("");
  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [maintenanceSettings, setMaintenanceSettings] = useState<MaintenanceSettings>({
    enabled: false,
    schedule: "daily",
    time: "12:00",
    tasks: ["backup", "optimize", "cleanup"]
  });

  // Fetch database status
  const { data: dbStatus, isLoading: statusLoading, error: statusError } = useQuery({
    queryKey: ['/api/admin/database/status'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/admin/database/status', {
          credentials: 'include'
        });
        if (!response.ok) {
          console.error('Database status fetch failed:', response.status, response.statusText);
          return {
            connected: false,
            size: "Connection Error",
            tables: 0,
            lastBackup: null,
            backupCount: 0,
            errorMessage: `HTTP ${response.status}: ${response.statusText}`
          };
        }
        return response.json();
      } catch (error) {
        console.error('Database status network error:', error);
        return {
          connected: false,
          size: "Network Error", 
          tables: 0,
          lastBackup: null,
          backupCount: 0,
          errorMessage: error.message || 'Network connection failed'
        };
      }
    },
    refetchInterval: 30000, // Refresh every 30 seconds
    retry: 1, // Only retry once
    retryDelay: 5000 // Wait 5 seconds before retry
  });

  // Fetch backups
  const { data: backups = [], isLoading: backupsLoading, error: backupsError } = useQuery({
    queryKey: ['/api/database/backups'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/database/backups', {
          credentials: 'include'
        });
        if (!response.ok) {
          console.error('Backups fetch failed:', response.status);
          return [];
        }
        return response.json();
      } catch (error) {
        console.error('Backups fetch error:', error);
        return [];
      }
    },
    retry: 1,
    retryDelay: 3000
  });

  // Fetch database tables
  const { data: dbTables = [], isLoading: tablesLoading } = useQuery({
    queryKey: ['/api/admin/database/tables'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/admin/database/tables', {
          credentials: 'include'
        });
        if (!response.ok) {
          console.error('Tables fetch failed:', response.status);
          return [];
        }
        return response.json();
      } catch (error) {
        console.error('Tables fetch error:', error);
        return [];
      }
    },
    retry: 1,
    retryDelay: 3000
  });

  // Fetch maintenance settings
  const { data: maintenanceData, isLoading: maintenanceLoading } = useQuery({
    queryKey: ['/api/admin/database/maintenance'],
    queryFn: async () => {
      try {
        const response = await fetch('/api/admin/database/maintenance', {
          credentials: 'include'
        });
        if (!response.ok) {
          console.error('Maintenance settings fetch failed:', response.status);
          return null;
        }
        return response.json();
      } catch (error) {
        console.error('Maintenance settings fetch error:', error);
        return null;
      }
    },
    retry: 1,
    retryDelay: 3000
  });

  // Update local state when data is loaded
  useEffect(() => {
    if (maintenanceData && !maintenanceLoading) {
      setMaintenanceSettings({
        enabled: maintenanceData.enabled || false,
        schedule: maintenanceData.schedule || 'daily',
        time: maintenanceData.time || '02:00',
        tasks: maintenanceData.tasks || ['backup', 'optimize', 'cleanup']
      });
    }
  }, [maintenanceData, maintenanceLoading]);

  // Create backup mutation
  const createBackupMutation = useMutation({
    mutationFn: async (description: string) => {
      try {
        const response = await fetch('/api/database/backup', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({ description })
        });
        
        if (!response.ok) {
          const errorData = await response.text();
          throw new Error(`Backup failed: ${response.status} - ${errorData}`);
        }
        
        return response.json();
      } catch (error) {
        console.error('Backup creation error:', error);
        throw error;
      }
    },
    onSuccess: () => {
      toast({
        title: "Backup created",
        description: "Database backup has been created successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/database/backups'] });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/database/status'] });
      setIsCreateBackupDialogOpen(false);
      setBackupDescription("");
    },
    onError: (error: any) => {
      toast({
        title: "Backup failed",
        description: error.message || "Failed to create database backup.",
        variant: "destructive",
      });
    }
  });

  // Restore backup mutation
  const restoreMutation = useMutation({
    mutationFn: async (backupPath: string) => {
      try {
        const response = await fetch('/api/database/restore', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify({ backupPath })
        });
        
        if (!response.ok) {
          const errorData = await response.text();
          throw new Error(`Restore failed: ${response.status} - ${errorData}`);
        }
        
        return response.json();
      } catch (error) {
        console.error('Restore error:', error);
        throw error;
      }
    },
    onSuccess: () => {
      toast({
        title: "Database restored",
        description: "Database has been restored successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/database/status'] });
      setIsRestoreDialogOpen(false);
      setSelectedBackup(null);
    },
    onError: (error: any) => {
      toast({
        title: "Restore failed",
        description: error.message || "Failed to restore database.",
        variant: "destructive",
      });
    }
  });

  // Delete backup mutation
  const deleteBackupMutation = useMutation({
    mutationFn: async (filename: string) => {
      try {
        const response = await fetch(`/api/database/backups/${encodeURIComponent(filename)}`, {
          method: 'DELETE',
          credentials: 'include'
        });
        
        if (!response.ok) {
          throw new Error(`Delete failed: ${response.status}`);
        }
        
        return response.json();
      } catch (error) {
        console.error('Delete backup error:', error);
        throw error;
      }
    },
    onSuccess: () => {
      toast({
        title: "Backup deleted",
        description: "Backup has been deleted successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/admin/database/backups'] });
    },
    onError: (error: any) => {
      toast({
        title: "Delete failed",
        description: error.message || "Failed to delete backup.",
        variant: "destructive",
      });
    }
  });

  // Maintenance settings mutation
  const updateMaintenanceMutation = useMutation({
    mutationFn: async (settings: MaintenanceSettings) => {
      try {
        const response = await fetch('/api/admin/database/maintenance', {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          credentials: 'include',
          body: JSON.stringify(settings)
        });
        
        if (!response.ok) {
          throw new Error(`Settings update failed: ${response.status}`);
        }
        
        return response.json();
      } catch (error) {
        console.error('Maintenance settings error:', error);
        throw error;
      }
    },
    onSuccess: (data) => {
      // Update local state with server response
      setMaintenanceSettings({
        enabled: data.enabled,
        schedule: data.schedule,
        time: data.time,
        tasks: data.tasks
      });
      
      // Invalidate and refetch maintenance settings
      queryClient.invalidateQueries({ queryKey: ['/api/admin/database/maintenance'] });
      
      toast({
        title: "Settings updated",
        description: "Maintenance settings have been updated successfully.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Update failed",
        description: error.message || "Failed to update maintenance settings.",
        variant: "destructive",
      });
    }
  });

  const handleCreateBackup = () => {
    createBackupMutation.mutate(backupDescription);
  };

  const handleRestoreBackup = () => {
    if (selectedBackup) {
      restoreMutation.mutate(selectedBackup.path || selectedBackup.filename);
    }
  };

  const handleDeleteBackup = (backup: BackupItem) => {
    if (confirm(`Are you sure you want to delete backup "${backup.filename}"? This action cannot be undone.`)) {
      deleteBackupMutation.mutate(backup.filename);
    }
  };

  const handleDownloadBackup = (backup: BackupItem) => {
    window.open(`/api/database/backups/${backup.filename}/download`, '_blank');
  };

  const handleMaintenanceSettingsChange = (field: keyof MaintenanceSettings, value: any) => {
    const newSettings = { ...maintenanceSettings, [field]: value };
    setMaintenanceSettings(newSettings);
    updateMaintenanceMutation.mutate(newSettings);
  };

  if (statusLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-semibold text-gray-800">Database Management</h1>
          <p className="text-sm text-gray-600">Monitor database status, create backups, and manage maintenance</p>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={dbStatus?.connected ? "default" : "destructive"}>
            {dbStatus?.connected ? "Connected" : "Disconnected"}
          </Badge>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="tables">Tables</TabsTrigger>
          <TabsTrigger value="backup">Backup</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Database Status</CardTitle>
                <DatabaseIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {dbStatus?.connected ? "Online" : "Offline"}
                </div>
                <p className="text-xs text-muted-foreground">
                  {dbStatus?.connected ? "Database is operational" : "Check connection"}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Database Size</CardTitle>
                <HardDriveIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{dbStatus?.size || "Unknown"}</div>
                <p className="text-xs text-muted-foreground">
                  {dbStatus?.tables || 0} tables
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Last Backup</CardTitle>
                <ClockIcon className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {dbStatus?.lastBackup ? formatDate(dbStatus.lastBackup) : "Never"}
                </div>
                <p className="text-xs text-muted-foreground">
                  {dbStatus?.backupCount || 0} total backups
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Health Status</CardTitle>
                {dbStatus?.connected ? (
                  <CheckCircleIcon className="h-4 w-4 text-green-500" />
                ) : (
                  <AlertCircleIcon className="h-4 w-4 text-red-500" />
                )}
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {dbStatus?.connected ? "Healthy" : "Issues"}
                </div>
                <p className="text-xs text-muted-foreground">
                  {dbStatus?.connected ? "All systems operational" : "Requires attention"}
                </p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Database Operations</CardTitle>
              <CardDescription>
                Perform maintenance operations on the database
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" className="flex items-center gap-2">
                  <RefreshCwIcon className="h-4 w-4" />
                  Optimize Database
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <DatabaseIcon className="h-4 w-4" />
                  Check Integrity
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <TrashIcon className="h-4 w-4" />
                  Clean Logs
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tables" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TableIcon className="h-5 w-5" />
                Database Tables
              </CardTitle>
              <CardDescription>
                View all tables in your PostgreSQL database
              </CardDescription>
            </CardHeader>
            <CardContent>
              {tablesLoading ? (
                <div className="flex items-center justify-center h-32">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : dbTables.length > 0 ? (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Table Name</TableHead>
                        <TableHead>Columns</TableHead>
                        <TableHead>Size</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {dbTables.map((table: any) => (
                        <TableRow key={table.table_name}>
                          <TableCell className="font-medium">{table.table_name}</TableCell>
                          <TableCell>{table.column_count}</TableCell>
                          <TableCell>{table.size}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              ) : (
                <div className="text-center py-8">
                  <DatabaseIcon className="h-12 w-12 mx-auto text-gray-400 mb-4" />
                  <p className="text-gray-500">No tables found in database</p>
                  {!dbStatus?.connected && (
                    <p className="text-sm text-red-500 mt-2">Database not connected</p>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="backup" className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="text-lg font-medium">Database Backup</h3>
              <p className="text-sm text-gray-600">Create and manage database backups</p>
            </div>
            <Dialog open={isCreateBackupDialogOpen} onOpenChange={setIsCreateBackupDialogOpen}>
              <DialogTrigger asChild>
                <Button>
                  <DownloadIcon className="mr-2 h-4 w-4" />
                  Create New Backup
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Create Database Backup</DialogTitle>
                  <DialogDescription>
                    Create a complete backup of all database tables and data
                  </DialogDescription>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <Label htmlFor="backup-description">Backup Description</Label>
                    <Textarea
                      id="backup-description"
                      placeholder="Enter a description for this backup..."
                      value={backupDescription}
                      onChange={(e) => setBackupDescription(e.target.value)}
                      className="mt-1"
                    />
                  </div>
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsCreateBackupDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button
                    onClick={handleCreateBackup}
                    disabled={createBackupMutation.isPending}
                  >
                    {createBackupMutation.isPending ? "Creating..." : "Create Backup"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Restore Database</CardTitle>
              <CardDescription>
                Select a backup to restore the database
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Dialog open={isRestoreDialogOpen} onOpenChange={setIsRestoreDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline">
                    <UploadIcon className="mr-2 h-4 w-4" />
                    Restore Database
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Restore Database</DialogTitle>
                    <DialogDescription>
                      ⚠️ Warning: This will replace all current data with the selected backup.
                    </DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div>
                      <Label>Select Backup</Label>
                      <Select onValueChange={(value) => {
                        const backup = backups.find(b => b.filename === value);
                        setSelectedBackup(backup || null);
                      }}>
                        <SelectTrigger className="mt-1">
                          <SelectValue placeholder="Choose a backup to restore" />
                        </SelectTrigger>
                        <SelectContent>
                          {backups.map((backup) => (
                            <SelectItem key={backup.filename} value={backup.filename}>
                              {backup.filename} ({formatDate(backup.created)})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    {selectedBackup && (
                      <div className="p-3 border rounded-md bg-amber-50 border-amber-200">
                        <p className="text-sm text-amber-800">
                          <strong>Selected:</strong> {selectedBackup.filename}<br />
                          <strong>Size:</strong> {selectedBackup.size}<br />
                          <strong>Created:</strong> {formatDate(selectedBackup.created)}
                        </p>
                      </div>
                    )}
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsRestoreDialogOpen(false)}>
                      Cancel
                    </Button>
                    <Button
                      variant="destructive"
                      onClick={handleRestoreBackup}
                      disabled={!selectedBackup || restoreMutation.isPending}
                    >
                      {restoreMutation.isPending ? "Restoring..." : "Restore Database"}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Available Backups</CardTitle>
              <CardDescription>
                Manage your database backups
              </CardDescription>
            </CardHeader>
            <CardContent>
              {backupsLoading ? (
                <div className="flex items-center justify-center h-32">
                  <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary"></div>
                </div>
              ) : backups.length > 0 ? (
                <div className="space-y-2">
                  {backups.map((backup) => (
                    <div key={backup.id} className="flex items-center justify-between p-3 border rounded-md">
                      <div>
                        <p className="font-medium">{backup.filename}</p>
                        <p className="text-sm text-gray-500">
                          {backup.description} • {backup.size} • {formatDate(backup.created)}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDownloadBackup(backup)}
                        >
                          <DownloadIcon className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => {
                            setSelectedBackup(backup);
                            setIsRestoreDialogOpen(true);
                          }}
                        >
                          Restore
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          className="text-red-500 border-red-200 hover:text-red-600 hover:bg-red-50"
                          onClick={() => handleDeleteBackup(backup)}
                          disabled={deleteBackupMutation.isPending}
                        >
                          Delete
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500">No backups available</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Automatic Database Maintenance</CardTitle>
              <CardDescription>
                Configure automated maintenance tasks to keep your database optimized
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-sm font-medium">Enable Automatic Maintenance</h3>
                  <p className="text-sm text-gray-500">
                    Automatically perform maintenance tasks on a schedule
                  </p>
                </div>
                <Switch
                  checked={maintenanceSettings.enabled}
                  onCheckedChange={(checked) =>
                    handleMaintenanceSettingsChange('enabled', checked)
                  }
                />
              </div>

              {maintenanceSettings.enabled && (
                <div className="space-y-4 p-4 border rounded-md bg-gray-50">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="schedule">Schedule</Label>
                      <Select
                        value={maintenanceSettings.schedule}
                        onValueChange={(value) =>
                          handleMaintenanceSettingsChange('schedule', value)
                        }
                      >
                        <SelectTrigger className="mt-1">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="daily">Daily</SelectItem>
                          <SelectItem value="weekly">Weekly</SelectItem>
                          <SelectItem value="monthly">Monthly</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="time">Time (24-hour format)</Label>
                      <Input
                        id="time"
                        type="time"
                        value={maintenanceSettings.time}
                        onChange={(e) =>
                          handleMaintenanceSettingsChange('time', e.target.value)
                        }
                        className="mt-1"
                      />
                    </div>
                  </div>

                  <div>
                    <Label>Maintenance Tasks</Label>
                    <div className="mt-2 space-y-2">
                      {[
                        { id: 'backup', label: 'Create automatic backup' },
                        { id: 'optimize', label: 'Optimize database tables' },
                        { id: 'cleanup', label: 'Clean up old logs' }
                      ].map((task) => (
                        <div key={task.id} className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            id={task.id}
                            checked={maintenanceSettings.tasks.includes(task.id)}
                            onChange={(e) => {
                              const tasks = e.target.checked
                                ? [...maintenanceSettings.tasks, task.id]
                                : maintenanceSettings.tasks.filter(t => t !== task.id);
                              handleMaintenanceSettingsChange('tasks', tasks);
                            }}
                            className="rounded border-gray-300"
                          />
                          <Label htmlFor={task.id} className="text-sm">
                            {task.label}
                          </Label>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Manual Maintenance</CardTitle>
              <CardDescription>
                Run maintenance tasks manually
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button variant="outline" className="flex items-center gap-2">
                  <RefreshCwIcon className="h-4 w-4" />
                  Optimize Tables
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <DatabaseIcon className="h-4 w-4" />
                  Rebuild Indexes
                </Button>
                <Button variant="outline" className="flex items-center gap-2">
                  <TrashIcon className="h-4 w-4" />
                  Clean Old Logs
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}